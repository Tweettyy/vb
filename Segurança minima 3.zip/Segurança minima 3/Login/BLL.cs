﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DataAccessLayer;
using System.Data;
using System.Data.SqlClient;

namespace BusinessLogicLayer
{
    public class BLL
    {
        public class Imagem
        {
            static public object loadpic()
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@id", 1),
             };
                return dal.executarScalar("select Img from Imagem where id=1", sqlParams);

            }
            static public DataTable Load()
            {
                DAL dal = new DAL();
                return dal.executarReader("select * from Imagem", null);
            }

            static public int insertImagem(byte[] img)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@img", img),

           };

                return dal.executarNonQuery("INSERT into Imagem (Img) VALUES(@img)", sqlParams);
            }
        }
        public class Clientes
        {

            static public DataTable Load()
            {
                DAL dal = new DAL();
                return dal.executarReader("select * from Clientes", null);
            }
            static public int insertCliente(string nome, string morada, string telefone)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@nome", nome),
                new SqlParameter("@morada", morada),
                new SqlParameter("@telefone", telefone)
           };

                return dal.executarNonQuery("INSERT into Cliente (Nome,Morada,Telefone) VALUES(@nome,@morada,@telefone)", sqlParams);
            }
            static public DataTable queryCliente_Like(String nome)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@nome", nome + "%")
                };
                return dal.executarReader("select * from Clientes where Nome like @nome", sqlParams);
            }
            static public DataTable queryCliente(int id)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@id", id)
                };
                return dal.executarReader("select * from Clientes where ID=@id", sqlParams);
            }
            static public DataTable queryCliente_2(int id, string nome)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@id", id),
                 new SqlParameter("@Nome", nome)
                };
                return dal.executarReader("select * from Clientes where ID=@id and Nome=@nome", sqlParams);
            }
            static public DataTable queryCliente_3(int id)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@id", id)
                };
                return dal.executarReader("select * from Clientes where ID=@id", sqlParams);
            }
            static public int updateCliente(string id, string nome, string morada, string telefone)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@id", id),
                new SqlParameter("@nome", nome),
                new SqlParameter("@morada", morada),
                new SqlParameter("@telefone", telefone)
            };
                return dal.executarNonQuery("update [Clientes] set [nome]=@nome, [morada]=@morada, [telefone]=@telefone where [id]=@id", sqlParams);
            }
            static public int deleteCliente(string id)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@id", id),

            };
                return dal.executarNonQuery("Delete From Clientes WHERE[id]=@id", sqlParams);
            }
            static public int alterarPerfil(string utilizador, String password, string imagem)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlparams = new SqlParameter[]{
                    new SqlParameter("@utilizador", utilizador),
                    new SqlParameter("@password", password),
                    new SqlParameter("@imagem", imagem)};

                return dal.executarNonQuery("update [utilizadores] set [password]=@password, [imagem]=@imagem where [utilizador]=@utilizador", sqlparams);
            }
            static public int alterarEstado(string utilizador, int estado)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlparams = new SqlParameter[]{
                    new SqlParameter("@utilizador", utilizador),
                    new SqlParameter("@estado", estado)};

                return dal.executarNonQuery("update utilizadores set estado=@estado where utilizador=@utilizador", sqlparams);
            }

        }
        public class Escola
        {
            static public DataTable LoadA()
            {
                DAL dal = new DAL();
                return dal.executarReader("select * from Aluno", null);
            }
            static public DataTable LoadI()
            {
                DAL dal = new DAL();
                return dal.executarReader("select * from Instrutores", null);
            }
            static public DataTable LoadAT()
            {
                DAL dal = new DAL();
                return dal.executarReader("select * from Aula_Teorica", null);
            }
            static public DataTable LoadAP()
            {
                DAL dal = new DAL();
                return dal.executarReader("select * from Aula_Pratica", null);
            }
            static public DataTable LoadET()
            {
                DAL dal = new DAL();
                return dal.executarReader("select * from Exame_Teorico", null);
            }
            static public DataTable LoadEP()
            {
                DAL dal = new DAL();
                return dal.executarReader("select * from Exame_Pratico", null);
            }
            static public DataTable LoadV()
            {
                DAL dal = new DAL();
                return dal.executarReader("select * from Veiculo", null);
            }
            static public DataTable LoadF()
            {
                DAL dal = new DAL();
                return dal.executarReader("select * from Funcionário", null);
            }
            static public DataTable Logar(int id, string password)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@id", id),
                 new SqlParameter("@password", password)
                };
                return dal.executarReader("select * from Funcionário where ID=@id and password=@password", sqlParams);
            }

            static public int insertAluno(string Nome, string CC, DateTime DT_Nascimento, string Morada, string Cod_Postal, string Telemovel, string Email, string NIF, string NIB, string Categoria)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@Nome", Nome),
                new SqlParameter("@CC", CC),
                new SqlParameter("@DT_Nascimento", DT_Nascimento),
                new SqlParameter("@Morada", Morada),
                new SqlParameter("@Cod_Postal", Cod_Postal),
                new SqlParameter("@Telemovel", Telemovel),
                new SqlParameter("@Email", Email),
                new SqlParameter("@NIF", NIF),
                new SqlParameter("@NIB", NIB),
                new SqlParameter("@Categoria", Categoria),
           };

                return dal.executarNonQuery("INSERT into Aluno (Nome,CC,DT_Nascimento,Morada,Cod_Postal,Telemovel,Email,NIF,NIB,Categoria) VALUES(@Nome,@CC,@DT_Nascimento,@Morada,@Cod_Postal,@Telemovel,@Email,@NIF,@NIB,@Categoria)", sqlParams);
            }

            static public int insertInstrutor(string Nome, string CC, DateTime DT_Nascimento, string Morada, string Cod_Postal, string Telemóvel, string Email, string NIF, string NIB, Boolean Habilitação)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@Nome", Nome),
                new SqlParameter("@CC", CC),
                new SqlParameter("@DT_Nascimento", DT_Nascimento),
                new SqlParameter("@Morada", Morada),
                new SqlParameter("@Cod_Postal", Cod_Postal),
                new SqlParameter("@Telemóvel", Telemóvel),
                new SqlParameter("@Email", Email),
                new SqlParameter("@NIF", NIF),
                new SqlParameter("@NIB", NIB),
                new SqlParameter("@Habilitação", Habilitação),
           };

                return dal.executarNonQuery("INSERT into Instrutores (Nome,CC,DT_Nascimento,Morada,Cod_Postal,Telemóvel,Email,NIF,NIB,Habilitação) VALUES(@Nome,@CC,@DT_Nascimento,@Morada,@Cod_Postal,@Telemóvel,@Email,@NIF,@NIB,@Habilitação)", sqlParams);
            }

            static public int insertAT(int Id_Instrutores, DateTime Data, TimeSpan Hora)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@Id_Instrutores", Id_Instrutores),
                new SqlParameter("@Data", Data),
                new SqlParameter("@Hora", Hora),

           };

                return dal.executarNonQuery("INSERT into Aula_Teorica (Id_Instrutores,Data,Hora) VALUES(@Id_Instrutores,@Data,@Hora)", sqlParams);
            }
            static public int insertAP(int Id_Instrutores, DateTime Data, TimeSpan Hora, int Nr_Aluno, string Matricula)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@Id_Instrutores", Id_Instrutores),
                new SqlParameter("@Data", Data),
                new SqlParameter("@Hora", Hora),
                new SqlParameter("@Nr_Aluno", Nr_Aluno),
                new SqlParameter("@Matricula", Matricula),
           };

                return dal.executarNonQuery("INSERT into Aula_Pratica (Id_Instrutores,Data,Hora,Nr_Aluno,Matricula) VALUES(@Id_Instrutores,@Data,@Hora,@Nr_Aluno,@Matricula)", sqlParams);
            }

            static public int insertET(int Id_Instrutores, DateTime Data, TimeSpan Hora, int Nr_Aluno)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@Id_Instrutores", Id_Instrutores),
                new SqlParameter("@Data", Data),
                new SqlParameter("@Hora", Hora),
                new SqlParameter("@Nr_Aluno", Nr_Aluno),

           };

                return dal.executarNonQuery("INSERT into Exame_Teorico (Id_Instrutores,Data,Hora,Nr_Aluno) VALUES(@Id_Instrutores,@Data,@Hora,@Nr_Aluno)", sqlParams);
            }
            static public int insertEP(int Id_Instrutores, DateTime Data, TimeSpan Hora, int Nr_Aluno, string Matricula)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@Id_Instrutores", Id_Instrutores),
                new SqlParameter("@Data", Data),
                new SqlParameter("@Hora", Hora),
                new SqlParameter("@Nr_Aluno", Nr_Aluno),
                new SqlParameter("@Matricula", Matricula),

           };

                return dal.executarNonQuery("INSERT into Exame_Pratico (Id_Instrutores,Data,Hora,Nr_Aluno,Matricula) VALUES(@Id_Instrutores,@Data,@Hora,@Nr_Aluno,@Matricula)", sqlParams);
            }


            static public int insertV(string Marca, string Modelo, string Ano, string Matricula, Boolean Revisões, string Inspeção, string Seguro)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@Marca", Marca),
                new SqlParameter("@Modelo", Modelo),
                new SqlParameter("@Ano", Ano),
                new SqlParameter("@Matricula", Matricula),
                new SqlParameter("@Revisões", Revisões),
                new SqlParameter("@Inspeção", Inspeção),
                new SqlParameter("@Seguro", Seguro),

           };

                return dal.executarNonQuery("INSERT into Veiculo (Marca,Modelo,Ano,Matricula,Revisões,Inspeção,Seguro) VALUES(@Marca,@Modelo,@Ano,@Matricula,@Revisões,@Inspeção,@Seguro)", sqlParams);
            }

            static public int insertF(string Password, string Nome, Boolean Admin)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@Password", Password),
                new SqlParameter("@Nome", Nome),
                new SqlParameter("@Admin", Admin),

           };

                return dal.executarNonQuery("INSERT into Funcionário (Password,Nome,Admin) VALUES(@Password,@Nome,@Admin)", sqlParams);
            }
            static public DataTable ShowA(int ID)
            {
                DAL dal = new DAL();

                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@ID", ID),
                };

                return dal.executarReader("select * from Aluno  where Nr_Aluno=@ID", sqlParams);
            }
            static public DataTable ShowI(int ID)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@ID", ID),
                };
                return dal.executarReader("select * from Instrutores where Id_Instrutores=@ID", sqlParams);

            }
            static public DataTable ShowAT(int ID)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@ID", ID),
                };
                return dal.executarReader("select * from Aula_Teorica  where Id_AulaT=@ID", sqlParams);
            }
            static public DataTable ShowAP(int ID)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@ID", ID),
                };
                return dal.executarReader("select * from Aula_Pratica  where Id_AulaP=@ID", sqlParams);
            }
            static public DataTable ShowET(int ID)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@ID", ID),
                };
                return dal.executarReader("select * from Exame_Teorico  where Id_ExameT=@ID", sqlParams);
            }
            static public DataTable ShowEP(int ID)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@ID", ID),
                };
                return dal.executarReader("select * from Exame_Pratico where Id_ExameP=@ID", sqlParams);
            }
            static public DataTable ShowV(string ID)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@ID", ID),
                };
                return dal.executarReader("select * from Veiculo where Matricula=@ID", sqlParams);
            }
            static public DataTable ShowF(int ID)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@ID", ID),

            };
                return dal.executarReader("select * from Funcionário where Id=@ID", sqlParams);
            }
            static public int updateA(int Nr_Aluno, string Nome, string CC, DateTime DT_Nascimento, string Morada, string Cod_Postal, string Telemovel, string Email, string NIF, string NIB, string Categoria)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@Nr_Aluno", Nr_Aluno),
                new SqlParameter("@Nome", Nome),
                new SqlParameter("@CC", CC),
                new SqlParameter("@DT_Nascimento", DT_Nascimento),
                new SqlParameter("@Morada", Morada),
                new SqlParameter("@Cod_Postal", Cod_Postal),
                new SqlParameter("@Telemovel", Telemovel),
                new SqlParameter("@Email", Email),
                new SqlParameter("@NIF", NIF),
                new SqlParameter("@NIB", NIB),
                new SqlParameter("@Categoria", Categoria),

            };
                return dal.executarNonQuery("update [Aluno] set [Nome]=@Nome,[CC]=@CC, [Dt_Nascimento]=@Dt_Nascimento,[Telemovel]=@Telemovel,[Email]=@Email, [NIB]=@NIB, [NIF]=@NIF, [Morada]=@Morada, [Cod_Postal]=@Cod_Postal, [Categoria]=@Categoria where [Nr_Aluno]=@Nr_Aluno", sqlParams);
            }
            static public int updateI(int Id_Instrutores, string Nome, string CC, DateTime DT_Nascimento, string Morada, string Cod_Postal, string Telemóvel, string Email, string NIF, string NIB, Boolean Habilitação)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@Id_Instrutores", Id_Instrutores),
                new SqlParameter("@Nome", Nome),
                new SqlParameter("@CC", CC),
                new SqlParameter("@DT_Nascimento", DT_Nascimento),
                new SqlParameter("@Morada", Morada),
                new SqlParameter("@Cod_Postal", Cod_Postal),
                new SqlParameter("@Telemóvel", Telemóvel),
                new SqlParameter("@Email", Email),
                new SqlParameter("@NIF", NIF),
                new SqlParameter("@NIB", NIB),
                new SqlParameter("@Habilitação", Habilitação),
           };

                return dal.executarNonQuery("update [Instrutores] set [Nome]=@Nome,[CC]=@CC, [Dt_Nascimento]=@Dt_Nascimento,[Telemóvel]=@Telemóvel,[Email]=@Email, [NIB]=@NIB, [NIF]=@NIF, [Morada]=@Morada, [Cod_Postal]=@Cod_Postal, [Habilitação]=@Habilitação where [Id_Instrutores]=@Id_Instrutores", sqlParams);
            }
            static public int updateAT(int Id_AulaT, int Id_Instrutores, DateTime Data, TimeSpan Hora)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@Id_AulaT", Id_AulaT),
                new SqlParameter("@Id_Instrutores", Id_Instrutores),
                new SqlParameter("@Data", Data),
                new SqlParameter("@Hora", Hora),

           };

                return dal.executarNonQuery("update [Aula_Teorica] set [Id_Instrutores]=@Id_Instrutores,[Data]=@Data, [Hora]=@Hora where [Id_AulaT]=@Id_AulaT", sqlParams);
            }
            static public int updateAP(int Id_AulaP, int Id_Instrutores, DateTime Data, TimeSpan Hora, int Nr_Aluno, string Matricula)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@Id_AulaP", Id_AulaP),
                new SqlParameter("@Id_Instrutores", Id_Instrutores),
                new SqlParameter("@Data", Data),
                new SqlParameter("@Hora", Hora),
                new SqlParameter("@Nr_Aluno", Nr_Aluno),
                new SqlParameter("@Matricula", Matricula),
           };

                return dal.executarNonQuery("update [Aula_Pratica] set [Id_Instrutores]=@Id_Instrutores,[Data]=@Data, [Hora]=@Hora,[Nr_Aluno]=@Nr_Aluno, [Matricula]=@Matricula where [Id_AulaP]=@Id_AulaP", sqlParams);
            }
            static public int updateET(int Id_ExameT, int Id_Instrutores, DateTime Data, TimeSpan Hora, int Nr_Aluno)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@Id_ExameT", Id_ExameT),
                new SqlParameter("@Id_Instrutores", Id_Instrutores),
                new SqlParameter("@Data", Data),
                new SqlParameter("@Hora", Hora),
                new SqlParameter("@Nr_Aluno", Nr_Aluno),

           };

                return dal.executarNonQuery("update [Exame_Teorico] set [Id_Instrutores]=@Id_Instrutores,[Data]=@Data, [Hora]=@Hora,[Nr_Aluno]=@Nr_Aluno where [Id_ExameT]=@Id_ExameT", sqlParams);
            }
            static public int updateEP(int Id_ExameP, int Id_Instrutores, DateTime Data, TimeSpan Hora, int Nr_Aluno, string Matricula)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@Id_ExameP", Id_ExameP),
                new SqlParameter("@Id_Instrutores", Id_Instrutores),
                new SqlParameter("@Data", Data),
                new SqlParameter("@Hora", Hora),
                new SqlParameter("@Nr_Aluno", Nr_Aluno),
                new SqlParameter("@Matricula", Matricula),

           };

                return dal.executarNonQuery("update [Exame_Pratico] set [Id_Instrutores]=@Id_Instrutores,[Data]=@Data, [Hora]=@Hora,[Nr_Aluno]=@Nr_Aluno, [Matricula]=@Matricula where [Id_ExameP]=@Id_ExameP", sqlParams);
            }
            static public int updateV(string Matricula, string Marca, string Modelo, string Ano, Boolean Revisões, string Inspeção, string Seguro)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@Matricula", Matricula),
                new SqlParameter("@Marca", Marca),
                new SqlParameter("@Modelo", Modelo),
                new SqlParameter("@Ano", Ano),
                new SqlParameter("@Revisões", Revisões),
                new SqlParameter("@Inspeção", Inspeção),
                new SqlParameter("@Seguro", Seguro),

           };

                return dal.executarNonQuery("update [Veiculo] set [Marca]=@Marca,[Modelo]=@Modelo, [Ano]=@Ano ,[Revisões]=@Revisões, [Inspeção]=@Inspeção,[Seguro]=@Seguro  where [Matricula]=@Matricula", sqlParams);
            }
            static public int updateF(int Id, string Password, string Nome, Boolean Admin)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@Id", Id),
                new SqlParameter("@Password", Password),
                new SqlParameter("@Nome", Nome),
                new SqlParameter("@Admin", Admin),

           };

                return dal.executarNonQuery("update [Funcionário] set [Password]=@Password,[Nome]=@Nome, [Admin]=@Admin  where [Id]=@Id", sqlParams);
            }
            static public int deleteA(int id)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@id", id),

            };
                return dal.executarNonQuery("Delete From Aluno WHERE[Nr_Aluno]=@id", sqlParams);
            }
            static public int deleteI(int id)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@id", id),

            };
                return dal.executarNonQuery("Delete From Instrutores WHERE[Id_Instrutores]=@id", sqlParams);
            }
            static public int deleteAT(int id)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@id", id),

            };
                return dal.executarNonQuery("Delete From Aula_Teorica WHERE[Id_AulaT]=@id", sqlParams);
            }
            static public int deleteAP(int id)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@id", id),

            };
                return dal.executarNonQuery("Delete From Aula_Pratica WHERE[Id_AulaP]=@id", sqlParams);
            }
            static public int deleteET(int id)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@id", id),

            };
                return dal.executarNonQuery("Delete From Exame_Teorica WHERE[Id_ExameT]=@id", sqlParams);
            }
            static public int deleteEP(int id)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@id", id),

            };
                return dal.executarNonQuery("Delete From Exame_Pratica WHERE[Id_ExameP]=@id", sqlParams);
            }
            static public int deleteV(string id)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@id", id),

            };
                return dal.executarNonQuery("Delete From Veiculo WHERE[Matricula]=@id", sqlParams);
            }
            static public int deleteF(int id)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@id", id),

            };
                return dal.executarNonQuery("Delete From Funcionário WHERE[Id]=@id", sqlParams);
            }
            static public DataTable PesquisarA(int p)
            {
                DAL dal = new DAL();

                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@p", p + "%"),
                };

                return dal.executarReader("select * from Aluno  where Nr_Aluno=@p  ", sqlParams);
            }
            static public DataTable PesquisarA2(string p)
            {
                DAL dal = new DAL();

                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@p" , p+ "%"),
                };

                return dal.executarReader("select * from Aluno  where Nome like @p or Telemovel like @p or CC like @p or Email like @p or NIB like @p or NIF like @p or Morada like @p or Cod_Postal like @p or Categoria like @p ", sqlParams);
            }
            static public DataTable PesquisarA3(DateTime p)
            {
                DAL dal = new DAL();

                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@p", p + "%"),
                };

                return dal.executarReader("select * from Aluno  where  Dt_Nascimento like @p  ", sqlParams);
            }
        }
    }
}