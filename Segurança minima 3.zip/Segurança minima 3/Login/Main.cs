﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using BusinessLogicLayer;
using System.Windows.Forms;

namespace Login
{

    public partial class Main : Form
    {
        bool flag, flag1, mostrarpass, tipo, tipo2, edit = false;
        public int btns, cell = 0;
        public string cell2 = "";
        public Main()
        {
            InitializeComponent();
        }
        public void load()
        {
            switch (btns)
            {
                case 1:
                    dataGridView1.DataSource = BLL.Escola.LoadA();
                    break;

                case 2:
                    dataGridView1.DataSource = BLL.Escola.LoadI();
                    break;

                case 3:
                    if (tipo2 == false)
                    {
                        dataGridView1.DataSource = BLL.Escola.LoadAT();
                    }
                    else
                    {
                        dataGridView1.DataSource = BLL.Escola.LoadAP();
                    }

                    break;

                case 4:
                    if (tipo2 == false)
                    {
                        dataGridView1.DataSource = BLL.Escola.LoadET();
                    }
                    else
                    {
                        dataGridView1.DataSource = BLL.Escola.LoadEP();
                    }

                    break;

                case 5:
                    dataGridView1.DataSource = BLL.Escola.LoadV();
                    break;


                case 6:
                    dataGridView1.DataSource = BLL.Escola.LoadF();
                    break;
            }
        }
        private void Main_Load(object sender, EventArgs e)
        {
            if (Login.admin == true)
            {
                button32.Visible = true;
            }


            label4.Text = DateTime.Now.ToLongTimeString();

            timer1.Start();
            label3.Text = DateTime.Now.ToShortDateString();

            dateTimePicker1.MaxDate = DateTime.Today.AddYears(-14);
            dateTimePicker1.MinDate = DateTime.Today.AddYears(-90);
            dateTimePicker2.MaxDate = DateTime.Today.AddYears(-18);
            dateTimePicker2.MinDate = DateTime.Today.AddYears(-90);

            textBox1.MouseHover += Common_MouseHover;
            textBox2.MouseHover += Common_MouseHover;
            textBox3.MouseHover += Common_MouseHover;
            textBox5.MouseHover += Common_MouseHover;
            textBox6.MouseHover += Common_MouseHover;
            textBox7.MouseHover += Common_MouseHover;
            textBox11.MouseHover += Common_MouseHover;
            textBox12.MouseHover += Common_MouseHover;
            textBox8.MouseHover += Common_MouseHover;
            textBox15.MouseHover += Common_MouseHover;
            textBox16.MouseHover += Common_MouseHover;
            maskedTextBox1.MouseHover += Common_MouseHover;
            maskedTextBox2.MouseHover += Common_MouseHover;
            maskedTextBox3.MouseHover += Common_MouseHover;
            maskedTextBox4.MouseHover += Common_MouseHover;
            maskedTextBox9.MouseHover += Common_MouseHover;
            maskedTextBox5.MouseHover += Common_MouseHover;
            maskedTextBox6.MouseHover += Common_MouseHover;
            maskedTextBox7.MouseHover += Common_MouseHover;
            maskedTextBox10.MouseHover += Common_MouseHover;
            maskedTextBox8.MouseHover += Common_MouseHover;
            maskedTextBox17.MouseHover += Common_MouseHover;
            maskedTextBox16.MouseHover += Common_MouseHover;
            maskedTextBox15.MouseHover += Common_MouseHover;
        }


        private void Common_MouseHover(object sender, EventArgs e)
        {
            TextBox btn = sender as TextBox;
            MaskedTextBox btn2 = sender as MaskedTextBox;
            if (btn != null)
                btn.Cursor = new Cursor(System.Windows.Forms.Application.StartupPath + "\\Ibm.cur");

            if (btn2 != null)
                btn2.Cursor = new Cursor(System.Windows.Forms.Application.StartupPath + "\\Ibm.cur");



        }






        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (panel3.Visible == false)
            {
                panel3.Visible = true;
                panel4.Visible = true;
            }
            else
            {
                panel3.Visible = false;
                panel4.Visible = false;
            }
        }

        private void label2_MouseHover(object sender, EventArgs e)
        {
            label2.ForeColor = Color.Tomato;

        }

        private void label2_MouseLeave(object sender, EventArgs e)
        {
            label2.ForeColor = Color.Black;
        }

        private void label1_MouseHover(object sender, EventArgs e)
        {
            label1.ForeColor = Color.Tomato;
        }

        private void label1_MouseLeave(object sender, EventArgs e)
        {
            label1.ForeColor = Color.Black;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Close();
            Login lg = new Login();
            lg.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label4.Text = DateTime.Now.ToLongTimeString();

        }



        private void button1_Click(object sender, EventArgs e)
        {
            if (flag1 == false)
            {
                btns = 1;
                try
                {
                    dataGridView1.DataSource = BLL.Escola.LoadA();
                }
                catch
                {
                    MessageBox.Show("Nao deu");
                }


                button6.Visible = true;


                button9.Visible = true;

                button1.BackColor = Color.FromArgb(255, 253, 199, 91);
                button2.BackColor = Color.Tomato;
                button3.BackColor = Color.Tomato;
                button4.BackColor = Color.Tomato;
                button5.BackColor = Color.Tomato;
                button32.BackColor = Color.Tomato;
                groupBox2.Visible = true;


                textBox16.Visible = true;
                pictureBox6.Visible = true;

            }
            if (flag1 == true)
            {

                textBox16.Visible = false;
                pictureBox6.Visible = false;

                checkBox6.Visible = false;
                checkBox7.Visible = false;
                checkBox7.Checked = false;
                checkBox6.Checked = false;


                button9.Visible = false;

                button6.Visible = false;

                button7.Visible = false;
                button8.Visible = false;
                button9.Visible = false;

                button1.BackColor = Color.Tomato;
                button2.BackColor = Color.Tomato;
                button3.BackColor = Color.Tomato;
                button4.BackColor = Color.Tomato;
                button5.BackColor = Color.Tomato;
                button32.BackColor = Color.Tomato;
                groupBox1.Visible = false;
                groupBox2.Visible = false;
                groupBox3.Visible = false;
                groupBox4.Visible = false;
                groupBox5.Visible = false;
                groupBox6.Visible = false;
                groupBox7.Visible = false;
            }
            if (flag1 == false)
            {
                flag1 = true;
            }
            else
            {
                flag1 = false;
            }



        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (flag1 == false)
            {
                btns = 2;
                try
                {
                    dataGridView1.DataSource = BLL.Escola.LoadI();
                }
                catch(Exception er)
                {
                    MessageBox.Show(Convert.ToString(er));
                }

                button6.Visible = true;

                button9.Visible = true;


                button2.BackColor = Color.FromArgb(255, 253, 199, 91);
                button1.BackColor = Color.Tomato;
                button3.BackColor = Color.Tomato;
                button4.BackColor = Color.Tomato;
                button5.BackColor = Color.Tomato;
                button32.BackColor = Color.Tomato;


                groupBox2.Visible = true;
                textBox16.Visible = true;
                pictureBox6.Visible = true;

            }
            if (flag1 == true)
            {

                textBox16.Visible = false;
                pictureBox6.Visible = false;

                checkBox6.Visible = false;
                checkBox7.Visible = false;
                checkBox7.Checked = false;
                checkBox6.Checked = false;

                button9.Visible = false;

                button6.Visible = false;
                button7.Visible = false;
                button8.Visible = false;
                button9.Visible = false;

                button1.BackColor = Color.Tomato;
                button2.BackColor = Color.Tomato;
                button3.BackColor = Color.Tomato;
                button4.BackColor = Color.Tomato;
                button5.BackColor = Color.Tomato;
                button32.BackColor = Color.Tomato;
                groupBox1.Visible = false;
                groupBox2.Visible = false;
                groupBox3.Visible = false;
                groupBox4.Visible = false;
                groupBox5.Visible = false;
                groupBox6.Visible = false;
                groupBox7.Visible = false;
            }
            if (flag1 == false)
            {
                flag1 = true;
            }
            else
            {
                flag1 = false;
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (flag1 == false)
            {
                btns = 3;

                tipo = false;

                checkBox6.Visible = true;
                checkBox7.Visible = true;


                button4.BackColor = Color.FromArgb(255, 253, 199, 91);
                button2.BackColor = Color.Tomato;
                button1.BackColor = Color.Tomato;
                button3.BackColor = Color.Tomato;
                button5.BackColor = Color.Tomato;
                button32.BackColor = Color.Tomato;
                button6.Visible = true;
                button9.Visible = true;


                groupBox2.Visible = true;
                groupBox1.Visible = false;
                groupBox3.Visible = false;


                checkBox7.Checked = false;
                checkBox6.Checked = true;
                textBox16.Visible = true;
                pictureBox6.Visible = true;
                try
                {

                    dataGridView1.DataSource = BLL.Escola.LoadAT();

                }
                catch (Exception er)
                {
                    MessageBox.Show("Nao deu");
                }

            }
            if (flag1 == true)
            {

                textBox16.Visible = false;
                pictureBox6.Visible = false;

                checkBox6.Visible = false;
                checkBox7.Visible = false;
                checkBox7.Checked = false;
                checkBox6.Checked = false;

                button9.Visible = false;

                button6.Visible = false;
                button7.Visible = false;
                button8.Visible = false;
                button9.Visible = false;

                button1.BackColor = Color.Tomato;
                button2.BackColor = Color.Tomato;
                button3.BackColor = Color.Tomato;
                button4.BackColor = Color.Tomato;
                button5.BackColor = Color.Tomato;
                button32.BackColor = Color.Tomato;
                groupBox1.Visible = false;
                groupBox2.Visible = false;
                groupBox3.Visible = false;
                groupBox4.Visible = false;
                groupBox5.Visible = false;
                groupBox6.Visible = false;
                groupBox7.Visible = false;
            }
            if (flag1 == false)
            {
                flag1 = true;
            }
            else
            {
                flag1 = false;
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (flag1 == false)
            {
                btns = 4;

                tipo = true;

                checkBox6.Visible = true;
                checkBox7.Visible = true;

                button6.Visible = true;


                button9.Visible = true;

                button3.BackColor = Color.FromArgb(255, 253, 199, 91);
                button2.BackColor = Color.Tomato;
                button4.BackColor = Color.Tomato;
                button1.BackColor = Color.Tomato;
                button5.BackColor = Color.Tomato;
                button32.BackColor = Color.Tomato;
                groupBox2.Visible = true;

                checkBox7.Checked = false;
                checkBox6.Checked = true;
                textBox16.Visible = true;
                pictureBox6.Visible = true;
                try
                {

                    dataGridView1.DataSource = BLL.Escola.LoadET();
                }
                catch (Exception er)
                {
                    MessageBox.Show(Convert.ToString(er));
                }
            }
            if (flag1 == true)
            {

                textBox16.Visible = false;
                pictureBox6.Visible = false;


                checkBox6.Visible = false;
                checkBox7.Visible = false;
                checkBox7.Checked = false;
                checkBox6.Checked = false;

                button9.Visible = false;

                button6.Visible = false;
                button7.Visible = false;
                button8.Visible = false;
                button9.Visible = false;

                button1.BackColor = Color.Tomato;
                button2.BackColor = Color.Tomato;
                button3.BackColor = Color.Tomato;
                button4.BackColor = Color.Tomato;
                button5.BackColor = Color.Tomato;
                button32.BackColor = Color.Tomato;
                groupBox1.Visible = false;
                groupBox2.Visible = false;
                groupBox3.Visible = false;
                groupBox4.Visible = false;
                groupBox5.Visible = false;
                groupBox6.Visible = false;
                groupBox7.Visible = false;
            }
            if (flag1 == false)
            {
                flag1 = true;
            }
            else
            {
                flag1 = false;
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {

            if (flag1 == false)
            {
                try
                {

                    dataGridView1.DataSource = BLL.Escola.LoadV();

                }
                catch (Exception er)
                {
                    Console.Write("n deu");
                }
                btns = 5;

                button5.BackColor = Color.FromArgb(255, 253, 199, 91);
                button2.BackColor = Color.Tomato;
                button3.BackColor = Color.Tomato;
                button4.BackColor = Color.Tomato;
                button1.BackColor = Color.Tomato;
                button32.BackColor = Color.Tomato;
                groupBox2.Visible = true;

                button9.Visible = true;
                button6.Visible = true;
                textBox16.Visible = true;
                pictureBox6.Visible = true;



            }
            if (flag1 == true)
            {

                textBox16.Visible = false;
                pictureBox6.Visible = false;

                checkBox6.Visible = false;
                checkBox7.Visible = false;
                checkBox7.Checked = false;
                checkBox6.Checked = false;

                button9.Visible = false;

                button6.Visible = false;
                button7.Visible = false;
                button8.Visible = false;
                button9.Visible = false;

                button1.BackColor = Color.Tomato;
                button2.BackColor = Color.Tomato;
                button3.BackColor = Color.Tomato;
                button4.BackColor = Color.Tomato;
                button5.BackColor = Color.Tomato;
                button32.BackColor = Color.Tomato;
                groupBox1.Visible = false;
                groupBox2.Visible = false;
                groupBox3.Visible = false;
                groupBox4.Visible = false;
                groupBox5.Visible = false;
                groupBox6.Visible = false;
                groupBox7.Visible = false;
            }
            if (flag1 == false)
            {
                flag1 = true;
            }
            else
            {
                flag1 = false;
            }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            switch (btns)
            {
                case 1:
                    groupBox1.Visible = true;
                    groupBox2.Visible = false;
                    textBox16.Visible = false;
                    pictureBox6.Visible = false;
                    maskedTextBox9.ResetText();
                    maskedTextBox4.ResetText();
                    maskedTextBox3.ResetText();
                    maskedTextBox2.ResetText();
                    maskedTextBox1.ResetText();
                    textBox11.ResetText();
                    comboBox1.ResetText();
                    break;

                case 2:
                    groupBox3.Visible = true;
                    groupBox2.Visible = false;
                    textBox16.Visible = false;
                    pictureBox6.Visible = false;
                    maskedTextBox10.ResetText();
                    maskedTextBox5.ResetText();
                    maskedTextBox6.ResetText();
                    maskedTextBox7.ResetText();
                    maskedTextBox8.ResetText();
                    comboBox2.ResetText();
                    textBox3.ResetText();
                    textBox6.ResetText();
                    textBox12.ResetText();
                    break;

                case 3:
                    dateTimePicker4.ShowUpDown = true;
                    groupBox2.Visible = false;
                    groupBox4.Visible = true;
                    pictureBox6.Visible = false;
                    textBox16.Visible = false;
                    textBox5.ResetText();
                    textBox2.ResetText();
                    maskedTextBox18.ResetText();
                    break;

                case 4:
                    dateTimePicker6.ShowUpDown = true;
                    groupBox5.Visible = true;
                    groupBox2.Visible = false;
                    textBox16.Visible = false;
                    pictureBox6.Visible = false;
                    maskedTextBox10.ResetText();
                    textBox8.ResetText();
                    maskedTextBox19.ResetText();
                    break;

                case 5:
                    groupBox6.Visible = true;
                    groupBox2.Visible = false;
                    textBox16.Visible = false;
                    pictureBox6.Visible = false;
                    comboBox3.ResetText();
                    textBox15.ResetText();
                    maskedTextBox16.ResetText();
                    maskedTextBox20.ResetText();
                    checkBox5.Checked = false;
                    maskedTextBox17.ResetText();
                    maskedTextBox15.ResetText();
                    break;


                case 6:
                    groupBox7.Visible = true;
                    groupBox2.Visible = false;
                    textBox16.Visible = false;
                    pictureBox6.Visible = false;
                    textBox17.ResetText();
                    textBox14.ResetText();
                    checkBox8.Checked = false;
                    break;
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
            groupBox2.Visible = true;
        }



        private void pictureBox4_Click(object sender, EventArgs e)
        {

            if (flag == false)
            {

                pictureBox4.Image = Escola_de_condução.Properties.Resources.expand;

                var poin = new Point(100, 90);


                this.WindowState = FormWindowState.Normal;
                this.Width = (1240);
                this.Height = (700);
                this.Location = poin;

                var point = new Point(11, 583);
                this.label4.Location = point;

                var point2 = new Point(11, 631);
                this.label3.Location = point2;

                var point3 = new Point(36, 622);
                this.panel5.Location = point3;

                var point4 = new Point(25, 669);
                this.panel6.Location = point4;

                var point5 = new Point(1125, 95);
                this.panel4.Location = point5;

                var point6 = new Point(916, 23);
                this.pictureBox4.Location = point6;

                var point7 = new Point(997, 23);
                this.pictureBox2.Location = point7;

                var point8 = new Point(300, 10);
                this.pictureBox3.Location = point8;

                var point9 = new Point(900, 380);
                this.button10.Location = point9;


                groupBox1.Size = new Size(1050, 440);
            }
            if (flag == true)
            {
                pictureBox4.Image = Escola_de_condução.Properties.Resources.minimize;


                this.WindowState = FormWindowState.Maximized;
                this.Width = (1440);
                this.Height = (900);


                var point = new Point(11, 783);
                this.label4.Location = point;

                var point2 = new Point(11, 831);
                this.label3.Location = point2;

                var point3 = new Point(36, 822);
                this.panel5.Location = point3;

                var point4 = new Point(25, 869);
                this.panel6.Location = point4;

                var point5 = new Point(1325, 95);
                this.panel4.Location = point5;

                var point6 = new Point(1116, 23);
                this.pictureBox4.Location = point6;

                var point7 = new Point(1197, 23);
                this.pictureBox2.Location = point7;

                var point8 = new Point(360, 10);
                this.pictureBox3.Location = point8;

                var point9 = new Point(1120, 380);
                this.button10.Location = point9;

                groupBox1.Size = new Size(1250, 440);
            }
            if (flag == false)
            {
                flag = true;
            }
            else
            {
                flag = false;
            }
        }



        private void label16_Click(object sender, EventArgs e)
        {

        }



        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Regex regex = new Regex(@"[0-9]");
            MatchCollection matches = regex.Matches(textBox1.Text);
            if (matches.Count > 0)
            {
                textBox1.Text = "";
            }
            textBox1.SelectionStart = 0;
        }
        private void textBox1_Click(object sender, EventArgs e)
        {

            textBox1.SelectionStart = 0;
        }
        private void textBox12_TextChanged(object sender, EventArgs e)
        {
            Regex regex = new Regex(@"[0-9]");
            MatchCollection matches = regex.Matches(textBox12.Text);
            if (matches.Count > 0)
            {
                textBox12.Text = "";
            }

        }
        private void textBox12_Click(object sender, EventArgs e)
        {

            textBox12.SelectionStart = 0;
        }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            Regex regex = new Regex(@"[A-Za-z]");
            MatchCollection matches = regex.Matches(textBox2.Text);
            if (matches.Count > 0)
            {
                textBox2.Text = "";
            }


        }
        private void textBox2_Click(object sender, EventArgs e)
        {

            textBox2.SelectionStart = 0;

        }
        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            Regex regex = new Regex(@"[A-Za-z]");
            MatchCollection matches = regex.Matches(textBox5.Text);
            if (matches.Count > 0)
            {
                textBox5.Text = "";
            }

        }
        private void textBox5_Click(object sender, EventArgs e)
        {

            textBox5.SelectionStart = 0;
        }
        private void textBox10_TextChanged(object sender, EventArgs e)
        {
            Regex regex = new Regex(@"[A-Za-z]");
            MatchCollection matches = regex.Matches(textBox10.Text);
            if (matches.Count > 0)
            {
                textBox10.Text = "";
            }

        }
        private void textBox10_Click(object sender, EventArgs e)
        {

            textBox10.SelectionStart = 0;
        }
        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            Regex regex = new Regex(@"[A-Za-z]");
            MatchCollection matches = regex.Matches(textBox8.Text);
            if (matches.Count > 0)
            {
                textBox8.Text = "";
            }
            textBox8.SelectionStart = 0;
        }
        private void textBox17_TextChanged(object sender, EventArgs e)
        {
            Regex regex = new Regex(@"[0-9]");
            MatchCollection matches = regex.Matches(textBox17.Text);
            if (matches.Count > 0)
            {
                textBox17.Text = "";
            }

        }
        private void textBox17_Click(object sender, EventArgs e)
        {

            textBox17.SelectionStart = 0;
        }
        private void maskedTextBox7_Click(object sender, EventArgs e)
        {
            maskedTextBox7.SelectionStart = 0;
        }

        private void maskedTextBox6_Click(object sender, EventArgs e)
        {
            maskedTextBox6.SelectionStart = 0;
        }

        private void maskedTextBox5_Click(object sender, EventArgs e)
        {
            maskedTextBox5.SelectionStart = 0;
        }

        private void textBox6_Click(object sender, EventArgs e)
        {
            textBox6.SelectionStart = 0;
        }
        private void maskedTextBox10_Click(object sender, EventArgs e)
        {
            maskedTextBox10.SelectionStart = 0;
        }

        private void maskedTextBox8_Click(object sender, EventArgs e)
        {
            maskedTextBox8.SelectionStart = 0;
        }

        private void textBox3_Click(object sender, EventArgs e)
        {
            textBox3.SelectionStart = 0;
        }

        private void maskedTextBox1_Click(object sender, EventArgs e)
        {
            maskedTextBox1.SelectionStart = 0;
        }

        private void textBox11_Click(object sender, EventArgs e)
        {
            textBox11.SelectionStart = 0;
        }

        private void maskedTextBox3_Click(object sender, EventArgs e)
        {
            maskedTextBox3.SelectionStart = 0;
        }

        private void maskedTextBox4_Click(object sender, EventArgs e)
        {
            maskedTextBox4.SelectionStart = 0;
        }

        private void textBox14_Click(object sender, EventArgs e)
        {
            textBox14.SelectionStart = 0;
        }

        private void maskedTextBox16_Click(object sender, EventArgs e)
        {
            maskedTextBox16.SelectionStart = 0;
        }

        private void maskedTextBox20_Click(object sender, EventArgs e)
        {
            maskedTextBox20.SelectionStart = 0;
        }

        private void maskedTextBox17_Click(object sender, EventArgs e)
        {
            maskedTextBox17.SelectionStart = 0;
        }
        private void maskedTextBox18_CLick(object sender, EventArgs e)
        {
            maskedTextBox18.SelectionStart = 0;
        }
        private void maskedTextBox19_Click(object sender, EventArgs e)
        {
            maskedTextBox19.SelectionStart = 0;
        }












        private void button13_Click(object sender, EventArgs e)
        {
            if (edit == false)
            {
                Boolean bit = false;
                if (comboBox2.Text == "Sim")
                {
                    bit = true;
                }
                try
                {

                    BLL.Escola.insertInstrutor(textBox12.Text, maskedTextBox7.Text, dateTimePicker2.Value.Date, textBox6.Text, maskedTextBox10.Text, maskedTextBox8.Text, textBox3.Text, maskedTextBox6.Text, maskedTextBox5.Text, bit);
                }
                catch (Exception er)
                {
                    MessageBox.Show(Convert.ToString(er));
                }

                textBox12.Text = "";
                maskedTextBox7.Text = "";
                textBox6.Text = "";
                maskedTextBox10.Text = "";
                maskedTextBox8.Text = "";
                textBox3.Text = "";
                maskedTextBox6.Text = "";
                maskedTextBox5.Text = "";
                comboBox2.Text = "";
                bit = false;
            }
            else
            {
                Boolean bit = false;
                if (comboBox2.Text == "Sim")
                {
                    bit = true;
                }
                DialogResult dialogResult = MessageBox.Show("Tem a certeza que deseja editar este instrutor?", "Confirmação", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    BLL.Escola.updateI(cell, textBox12.Text, maskedTextBox7.Text, dateTimePicker2.Value.Date, textBox6.Text, maskedTextBox10.Text, maskedTextBox8.Text, textBox3.Text, maskedTextBox6.Text, maskedTextBox5.Text, bit);

                }
                bit = false;
            }



        }
        private void maskedTextBox2_Click(object sender, EventArgs e)
        {
            maskedTextBox2.SelectionStart = 0;
        }

        private void button19_Click(object sender, EventArgs e)
        {
            if (tipo2 == false)
            {
                if (edit == false)
                {
                    try
                    {

                        BLL.Escola.insertAT(Convert.ToInt32(textBox2.Text), dateTimePicker3.Value.Date, dateTimePicker4.Value.TimeOfDay);

                    }
                    catch (Exception er)
                    {
                        MessageBox.Show(Convert.ToString(er));
                    }


                }
                else
                {
                    DialogResult dialogResult = MessageBox.Show("Tem a certeza que deseja editar esta aula teorica?", "Confirmação", MessageBoxButtons.YesNo);
                    if (dialogResult == DialogResult.Yes)
                    {
                        BLL.Escola.updateAT(cell, Convert.ToInt32(textBox2.Text), dateTimePicker3.Value.Date, dateTimePicker4.Value.TimeOfDay);

                    }


                }
            }

            else
            {
                if (edit == false)
                {
                    try
                    {

                        BLL.Escola.insertAP(Convert.ToInt32(textBox2.Text), dateTimePicker3.Value.Date, dateTimePicker4.Value.TimeOfDay, Convert.ToInt32(textBox5.Text), maskedTextBox18.Text);

                    }
                    catch (Exception er)
                    {
                        MessageBox.Show(Convert.ToString(er));
                    }


                }
                else
                {
                    DialogResult dialogResult = MessageBox.Show("Tem a certeza que deseja editar esta aula pratica?", "Confirmação", MessageBoxButtons.YesNo);
                    if (dialogResult == DialogResult.Yes)
                    {
                        BLL.Escola.updateAP(cell, Convert.ToInt32(textBox2.Text), dateTimePicker3.Value.Date, dateTimePicker4.Value.TimeOfDay, Convert.ToInt32(textBox5.Text), maskedTextBox18.Text);

                    }

                }



            }
            textBox2.Text = "";
            textBox5.Text = "";
            maskedTextBox18.Text = "";



        }

        private void button20_Click(object sender, EventArgs e)
        {
            groupBox2.Visible = true;
            groupBox4.Visible = false;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            groupBox2.Visible = true;
            groupBox3.Visible = false;
            groupBox1.Visible = false;
            groupBox4.Visible = false;
            groupBox5.Visible = false;
            groupBox6.Visible = false;
            groupBox7.Visible = false;
            load();
        }

        private void textBox15_Click(object sender, EventArgs e)
        {
            textBox15.SelectionStart = 0;
        }
        private void button32_Click(object sender, EventArgs e)
        {
            if (flag1 == false)
            {
                try
                {

                    dataGridView1.DataSource = BLL.Escola.LoadF();

                }
                catch (Exception er)
                {
                    MessageBox.Show(Convert.ToString(er));
                }
                btns = 6;

                button32.BackColor = Color.FromArgb(255, 253, 199, 91);
                button5.BackColor = Color.Tomato;
                button2.BackColor = Color.Tomato;
                button3.BackColor = Color.Tomato;
                button4.BackColor = Color.Tomato;
                button1.BackColor = Color.Tomato;
                groupBox2.Visible = true;

                button9.Visible = true;
                button6.Visible = true;
                textBox16.Visible = true;
                pictureBox6.Visible = true;



            }
            if (flag1 == true)
            {
                checkBox6.Visible = false;
                checkBox7.Visible = false;

                button9.Visible = false;

                button6.Visible = false;
                button7.Visible = false;
                button8.Visible = false;
                button9.Visible = false;

                button1.BackColor = Color.Tomato;
                button2.BackColor = Color.Tomato;
                button3.BackColor = Color.Tomato;
                button4.BackColor = Color.Tomato;
                button5.BackColor = Color.Tomato;
                button32.BackColor = Color.Tomato;
                groupBox1.Visible = false;
                groupBox2.Visible = false;
                groupBox3.Visible = false;
                groupBox4.Visible = false;
                groupBox5.Visible = false;
                groupBox6.Visible = false;
                groupBox7.Visible = false;
            }
            if (flag1 == false)
            {
                flag1 = true;
            }
            else
            {
                flag1 = false;
            }



        }


        private void checkBox7_Click(object sender, EventArgs e)
        {
            tipo2 = true;
            label30.Visible = true;
            textBox5.Visible = true;
            label29.Visible = true;
            maskedTextBox18.Visible = true;
            label32.Visible = true;
            maskedTextBox19.Visible = true;
            checkBox6.Checked = false;
            checkBox7.Checked = true;
            if (tipo == false)
            {
                try
                {

                    dataGridView1.DataSource = BLL.Escola.LoadAP();

                }
                catch (Exception er)
                {
                    Console.Write("n deu");
                }
            }
            else
            {
                try
                {

                    dataGridView1.DataSource = BLL.Escola.LoadEP();

                }
                catch (Exception er)
                {
                    Console.Write(er);
                }
            }
        }
        private void maskedTextBox15_Click(object sender, EventArgs e)
        {
            maskedTextBox15.SelectionStart = 0;
        }
        private void checkBox6_Click(object sender, EventArgs e)
        {
            tipo2 = false;
            label30.Visible = false;
            textBox5.Visible = false;
            label29.Visible = false;
            maskedTextBox18.Visible = false;
            label32.Visible = false;
            maskedTextBox19.Visible = false;




            checkBox7.Checked = false;
            checkBox6.Checked = true;
            if (tipo == false)
            {
                try
                {

                    dataGridView1.DataSource = BLL.Escola.LoadAT();

                }
                catch (Exception er)
                {
                    Console.Write("n deu");
                }
            }
            else
            {
                try
                {

                    dataGridView1.DataSource = BLL.Escola.LoadET();

                }
                catch (Exception er)
                {
                    Console.Write(er);
                }
            }
        }
        private void textBox7_Click(object sender, EventArgs e)
        {
            textBox7.SelectionStart = 0;
        }

        private void maskedTextBox9_Click(object sender, EventArgs e)
        {
            maskedTextBox9.SelectionStart = 0;
        }
        private void button25_Click(object sender, EventArgs e)
        {
            if (tipo2 == false)
            {
                if (edit == false)
                {
                    try
                    {

                        BLL.Escola.insertET(Convert.ToInt32(textBox10.Text), dateTimePicker5.Value.Date, dateTimePicker6.Value.TimeOfDay, Convert.ToInt32(textBox8.Text));

                    }
                    catch (Exception er)
                    {
                        MessageBox.Show(Convert.ToString(er));
                    }

                }
                else
                {
                    DialogResult dialogResult = MessageBox.Show("Tem a certeza que deseja editar este exame teorico?", "Confirmação", MessageBoxButtons.YesNo);
                    if (dialogResult == DialogResult.Yes)
                    {
                        BLL.Escola.updateET(cell, Convert.ToInt32(textBox10.Text), dateTimePicker5.Value.Date, dateTimePicker6.Value.TimeOfDay, Convert.ToInt32(textBox8.Text));

                    }

                }




            }
            else
            {
                if (edit == false)
                {
                    try
                    {
                        BLL.Escola.insertEP(Convert.ToInt32(textBox10.Text), dateTimePicker5.Value.Date, dateTimePicker6.Value.TimeOfDay, Convert.ToInt32(textBox8.Text), maskedTextBox19.Text);

                    }
                    catch (Exception er)
                    {
                        MessageBox.Show(Convert.ToString(er));
                    }

                }
                else
                {
                    DialogResult dialogResult = MessageBox.Show("Tem a certeza que deseja editar este exame pratico?", "Confirmação", MessageBoxButtons.YesNo);
                    if (dialogResult == DialogResult.Yes)
                    {
                        BLL.Escola.updateEP(cell, Convert.ToInt32(textBox10.Text), dateTimePicker5.Value.Date, dateTimePicker6.Value.TimeOfDay, Convert.ToInt32(textBox8.Text), maskedTextBox19.Text);

                    }

                }



            }
            textBox10.Text = "";
            textBox8.Text = "";
            maskedTextBox19.Text = "";
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //button8.Visible = true;
            // button7.Visible = true;

        }

        private void button7_Click(object sender, EventArgs e)
        {
            switch (btns)
            {
                case 1:
                    BLL.Escola.deleteA(cell);
                    break;

                case 2:
                    BLL.Escola.deleteI(cell);
                    break;

                case 3:
                    if (tipo2 == false)
                    {
                        BLL.Escola.deleteAT(cell);
                    }
                    else
                    {
                        BLL.Escola.deleteAP(cell);
                    }
                    break;

                case 4:
                    if (tipo2 == false)
                    {
                        BLL.Escola.deleteET(cell);
                    }
                    else
                    {
                        BLL.Escola.deleteEP(cell);
                    }
                    break;

                case 5:
                    BLL.Escola.deleteV(cell2);
                    break;


                case 6:
                    BLL.Escola.deleteF(cell);
                    break;
            }
            load();
        }

        private void textBox16_TextChanged(object sender, EventArgs e)
        {

        }


        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            button8.Visible = true;
            button7.Visible = true;
            try
            {
                cell = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value);
                // MessageBox.Show(Convert.ToString(cell));
            }
            catch
            {
                try
                {
                    cell2 = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells[0].Value);
                    //MessageBox.Show(Convert.ToString(cell2))
                }
                catch
                {
                    cell = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value);
                }
                ;
            }




        }

        private void button8_Click(object sender, EventArgs e)
        {
            edit = true;
            switch (btns)
            {
                case 1:
                    groupBox1.Visible = true;
                    groupBox2.Visible = false;
                    textBox1.Text = BLL.Escola.ShowA(cell).Rows[0][1].ToString();
                    maskedTextBox2.Text = BLL.Escola.ShowA(cell).Rows[0][3].ToString();
                    dateTimePicker1.Text = BLL.Escola.ShowA(cell).Rows[0][4].ToString();
                    textBox7.Text = BLL.Escola.ShowA(cell).Rows[0][8].ToString();
                    maskedTextBox9.Text = BLL.Escola.ShowA(cell).Rows[0][9].ToString();
                    maskedTextBox1.Text = BLL.Escola.ShowA(cell).Rows[0][2].ToString();
                    textBox11.Text = BLL.Escola.ShowA(cell).Rows[0][5].ToString();
                    maskedTextBox3.Text = BLL.Escola.ShowA(cell).Rows[0][7].ToString();
                    maskedTextBox4.Text = BLL.Escola.ShowA(cell).Rows[0][6].ToString();
                    comboBox1.Text = BLL.Escola.ShowA(cell).Rows[0][10].ToString();
                    break;

                case 2:
                    groupBox3.Visible = true;
                    groupBox2.Visible = false;
                    textBox12.Text = BLL.Escola.ShowI(cell).Rows[0][1].ToString();
                    dateTimePicker2.Text = BLL.Escola.ShowI(cell).Rows[0][7].ToString();
                    maskedTextBox7.Text = BLL.Escola.ShowI(cell).Rows[0][2].ToString();
                    maskedTextBox6.Text = BLL.Escola.ShowI(cell).Rows[0][6].ToString();
                    maskedTextBox5.Text = BLL.Escola.ShowI(cell).Rows[0][5].ToString();
                    textBox6.Text = BLL.Escola.ShowI(cell).Rows[0][8].ToString();
                    maskedTextBox10.Text = BLL.Escola.ShowI(cell).Rows[0][9].ToString();
                    maskedTextBox8.Text = BLL.Escola.ShowI(cell).Rows[0][3].ToString();
                    textBox3.Text = BLL.Escola.ShowI(cell).Rows[0][4].ToString();
                    comboBox2.Text = BLL.Escola.ShowI(cell).Rows[0][10].ToString();
                    break;

                case 3:
                    dateTimePicker4.ShowUpDown = true;
                    groupBox2.Visible = false;
                    groupBox4.Visible = true;
                    if (tipo2 == false)
                    {
                        textBox2.Text = BLL.Escola.ShowAT(cell).Rows[0][1].ToString();
                        dateTimePicker3.Text = BLL.Escola.ShowAT(cell).Rows[0][2].ToString();
                        dateTimePicker4.Text = BLL.Escola.ShowAT(cell).Rows[0][3].ToString();
                    }
                    else
                    {
                        textBox2.Text = BLL.Escola.ShowAP(cell).Rows[0][1].ToString();
                        dateTimePicker3.Text = BLL.Escola.ShowAP(cell).Rows[0][2].ToString();
                        dateTimePicker4.Text = BLL.Escola.ShowAP(cell).Rows[0][3].ToString();
                        textBox5.Text = BLL.Escola.ShowAP(cell).Rows[0][4].ToString();
                        maskedTextBox18.Text = BLL.Escola.ShowAP(cell).Rows[0][5].ToString();
                    }
                    break;

                case 4:
                    dateTimePicker6.ShowUpDown = true;
                    groupBox5.Visible = true;
                    groupBox2.Visible = false;
                    if (tipo2 == false)
                    {
                        textBox10.Text = BLL.Escola.ShowET(cell).Rows[0][1].ToString();
                        dateTimePicker5.Text = BLL.Escola.ShowET(cell).Rows[0][3].ToString();
                        dateTimePicker6.Text = BLL.Escola.ShowET(cell).Rows[0][4].ToString();
                        textBox8.Text = BLL.Escola.ShowET(cell).Rows[0][2].ToString();
                    }
                    else
                    {
                        textBox10.Text = BLL.Escola.ShowEP(cell).Rows[0][2].ToString();
                        dateTimePicker5.Text = BLL.Escola.ShowEP(cell).Rows[0][4].ToString();
                        dateTimePicker6.Text = BLL.Escola.ShowEP(cell).Rows[0][5].ToString();
                        textBox8.Text = BLL.Escola.ShowEP(cell).Rows[0][1].ToString();
                        maskedTextBox19.Text = BLL.Escola.ShowEP(cell).Rows[0][3].ToString();
                    }
                    break;

                case 5:
                    groupBox6.Visible = true;
                    groupBox2.Visible = false;
                    comboBox3.Text = BLL.Escola.ShowV(cell2).Rows[0][1].ToString();
                    textBox15.Text = BLL.Escola.ShowV(cell2).Rows[0][2].ToString();
                    maskedTextBox16.Text = BLL.Escola.ShowV(cell2).Rows[0][3].ToString();
                    maskedTextBox20.Text = BLL.Escola.ShowV(cell2).Rows[0][0].ToString();
                    if (Convert.ToBoolean(BLL.Escola.ShowV(cell2).Rows[0][6]) == true)
                    {
                        checkBox5.Checked = true;
                    }
                    maskedTextBox17.Text = BLL.Escola.ShowV(cell2).Rows[0][5].ToString();
                    maskedTextBox15.Text = BLL.Escola.ShowV(cell2).Rows[0][4].ToString();
                    break;


                case 6:
                    groupBox7.Visible = true;
                    groupBox2.Visible = false;
                    textBox17.Text = BLL.Escola.ShowF(cell).Rows[0][2].ToString();
                    textBox14.Text = BLL.Escola.ShowF(cell).Rows[0][1].ToString();
                    if (Convert.ToBoolean(BLL.Escola.ShowF(cell).Rows[0][3]) == true)
                    {
                        checkBox8.Checked = true;
                    }
                    break;
            }
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            if (mostrarpass == false)
            {

                pictureBox5.BackgroundImage = Escola_de_condução.Properties.Resources.hide;
                textBox14.PasswordChar = '\0';
                mostrarpass = true;
            }
            else
            {
                pictureBox5.BackgroundImage = Escola_de_condução.Properties.Resources.view;
                textBox14.PasswordChar = '*';
                mostrarpass = false;
            }
        }


        private void button30_Click(object sender, EventArgs e)
        {
            if (edit == false)
            {
                bool bit = false;
                if (checkBox5.Checked == true)
                {
                    bit = true;
                }
                try
                {
                    BLL.Escola.insertV(comboBox3.Text, textBox15.Text, maskedTextBox16.Text, maskedTextBox20.Text, bit, maskedTextBox17.Text, maskedTextBox15.Text);



                }
                catch (Exception er)
                {

                    MessageBox.Show(Convert.ToString(er));


                }
                comboBox3.Text = "";
                textBox15.Text = "";
                maskedTextBox16.Text = "";
                maskedTextBox20.Text = "";
                checkBox5.Checked = false;
                bit = false;
                maskedTextBox17.Text = "";
                maskedTextBox15.Text = "";

            }
            else
            {
                Boolean bit = false;
                if (checkBox5.Checked == true)
                {
                    bit = true;
                }
                DialogResult dialogResult = MessageBox.Show("Tem a certeza que deseja editar este veiculo?", "Confirmação", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    try
                    {
                        BLL.Escola.updateV(cell2, comboBox3.Text, textBox15.Text, maskedTextBox16.Text, bit, maskedTextBox17.Text, maskedTextBox15.Text);



                    }
                    catch (Exception er)
                    {

                        MessageBox.Show(Convert.ToString(er));


                    }


                }

            }
        }

        private void button34_Click(object sender, EventArgs e)
        {
            Boolean bit = false;
            if (checkBox8.Checked == true)
            {
                bit = true;
            }
            if (edit == false)
            {

                try
                {
                    BLL.Escola.insertF(textBox14.Text, textBox17.Text, bit);
                }
                catch (Exception er)
                {
                    MessageBox.Show(Convert.ToString(er));
                }
                textBox17.Text = "";
                textBox14.Text = "";
                checkBox8.Checked = false;
                bit = false;
            }
            else
            {

                try
                {
                    BLL.Escola.updateF(cell, textBox14.Text, textBox17.Text, bit);
                }
                catch (Exception er)
                {
                    MessageBox.Show(Convert.ToString(er));
                }
            }

        }



        private void button10_Click(object sender, EventArgs e)
        {
            if (edit == false)
            {
                try
                {
                    BLL.Escola.insertAluno(textBox1.Text, maskedTextBox2.Text, dateTimePicker1.Value.Date, textBox7.Text, maskedTextBox9.Text, maskedTextBox1.Text, textBox11.Text, maskedTextBox3.Text, maskedTextBox4.Text, comboBox1.Text);

                }
                catch (Exception er)
                {
                    MessageBox.Show(Convert.ToString(er));
                }
                textBox1.Text = "";
                maskedTextBox2.Text = "";
                dateTimePicker1.Text = "";
                textBox7.Text = "";
                maskedTextBox9.Text = "";
                maskedTextBox1.Text = "";
                textBox11.Text = "";
                maskedTextBox3.Text = "";
                maskedTextBox4.Text = "";
                comboBox1.Text = "";
            }
            else
            {
                DialogResult dialogResult = MessageBox.Show("Tem a certeza que deseja editar este aluno?", "Confirmação", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    BLL.Escola.updateA(cell, textBox1.Text, maskedTextBox2.Text, dateTimePicker1.Value.Date, textBox7.Text, maskedTextBox9.Text, maskedTextBox1.Text, textBox11.Text, maskedTextBox3.Text, maskedTextBox4.Text, comboBox1.Text);

                }

            }



        }
    }
}
