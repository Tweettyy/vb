import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.border.EmptyBorder;
import java.awt.Frame;
import java.awt.Color;
import java.awt.Point;
import java.awt.SystemColor;
import javax.swing.border.MatteBorder;
import javax.swing.JLabel;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.font.TextAttribute;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.border.TitledBorder;
import javax.swing.text.MaskFormatter;

import org.jdesktop.swingx.JXDatePicker;

import net.proteanit.sql.DbUtils;

import javax.swing.UIManager;
import javax.swing.border.CompoundBorder;
import javax.swing.border.LineBorder;
import java.awt.Cursor;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;

import java.awt.event.InputMethodListener;
import java.awt.event.InputMethodEvent;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JCheckBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollBar;
import javax.swing.JList;
import javax.swing.JTextArea;
import javax.swing.JSpinner;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Main extends JFrame {

	private JPanel Main;
	private final JPanel panel = new JPanel();

	/**
	 * Launch the application.
	 */
	
	ImageIcon logo = new ImageIcon(Main.class.getResource("logo.png"));
	ImageIcon search = new ImageIcon(Main.class.getResource("Search.png"));
	public static Connection con;
	boolean tipo,edit =false;
	int btns = 2;
	public static  int value,row=0;
	public static String marcasql,modelosql,auxmatricula="";
	public JTable Tabela;
	public JComboBox op = new JComboBox();
	public static JXDatePicker picker = new JXDatePicker();
	private JFormattedTextField textmatricula;
	private JTextField textField;
	public static JPanel adcV = new JPanel();
	public static JPanel adcA = new JPanel();
	public static JScrollPane tab = new JScrollPane();
	private JTextField textmodelo;
	private JTextField sb;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField pre�o;
	 
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					Main frame = new Main();
					frame.setResizable(false);
					//frame.setUndecorated(true);		
					frame.setVisible(true);
					frame.setBackground(Color.LIGHT_GRAY);
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					frame.setBounds(150, 100, 1100, 700);
					frame.setVisible(true);
								
					
					adcV.setVisible(false);
					adcV.setBackground(Color.WHITE);
					adcV.setBounds(165, 120, 929, 552);
					adcV.setLayout(null);
					adcV.setVisible(false);
					frame.getContentPane().add(adcV);
					adcA.setVisible(false);
					adcA.setBackground(Color.WHITE);
					adcA.setBounds(165, 120, 929, 552);
					adcA.setLayout(null);
					adcA.setVisible(false);
					frame.getContentPane().add(adcA);
					
					
			        
			        picker.setDate(Calendar.getInstance().getTime());
			        picker.setTimeZone(Calendar.getInstance().getTimeZone());
			        picker.setFormats(new SimpleDateFormat("dd.MM.yyyy HH:mm"));
			        
			        picker.setBounds(200,327,145,30);
			        
			        
			        adcA.add(picker);
			        
			       /* JXDatePicker picker1 = new JXDatePicker();
			        picker1.setDate(Calendar.getInstance().getTime());
			        picker1.setTimeZone(Calendar.getInstance().getTimeZone());
			        picker1.setFormats(new SimpleDateFormat("dd.MM.yyyy HH:mm"));
			        picker1.setBounds(620,147,145,20);
			        
			        
			        adcA.add(picker1);
			        
			        JXDatePicker picker2 = new JXDatePicker();
			        picker2.setDate(Calendar.getInstance().getTime());
			        picker2.setTimeZone(Calendar.getInstance().getTimeZone());
			        picker2.setFormats(new SimpleDateFormat("dd.MM.yyyy HH:mm"));
			        picker2.setBounds(110,74,145,20);*/
                  
					
					
			        
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	void loadv(){
		try{
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/rentacar","root","");
			Statement stmt=con.createStatement();
			String sql="Select Matricula,Marca,Modelo,Classe,Ano,Seguro,Inspe��o, Tp_Combustivel, Cor, NPortas,NLugares,Activo from Veiculos where Remove='0'";
			ResultSet rs=stmt.executeQuery(sql);
			
			Tabela.setModel(DbUtils.resultSetToTableModel(rs));
			Tabela.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
			System.out.println("Carregar dados para a tabela");
			
		
			con.close();
			}catch(Exception ee){System.out.println(ee);}	
			
			

	}
	void loadaux(){
		try{
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/rentacar","root","");
			Statement stmt=con.createStatement();
			
			JTable aux=new JTable();
			aux.setVisible(false);
			
			String sql2="Select Marca from Veiculos Where Matricula=('"+auxmatricula+"')";
			ResultSet rs2=stmt.executeQuery(sql2);
			aux.setModel(DbUtils.resultSetToTableModel(rs2));
			marcasql=aux.getModel().getValueAt(0,0).toString();
			
			String sql3="Select Modelo from Veiculos Where Matricula=('"+auxmatricula+"')";
			ResultSet rs3=stmt.executeQuery(sql3);
			aux.setModel(DbUtils.resultSetToTableModel(rs3));
			modelosql=aux.getModel().getValueAt(0,0).toString();
			
			con.close();
			}catch(Exception ee){System.out.println(ee);}	
			
			

	}
	void loada(){
		try{
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/rentacar","root","");
			Statement stmt=con.createStatement();
			String sql="Select Id,Matricula,Marca,Modelo,Nome_Cliente, CC, Data_Inicial, Data_Final, Combustivel,Prote��o_Total, Sinal, Pre�o from Alugados where Remove='0'";
			ResultSet rs=stmt.executeQuery(sql);
			

			Tabela.setModel(DbUtils.resultSetToTableModel(rs));
			Tabela.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
			System.out.println("Carregar dados para a tabela");
			con.close();
			}catch(Exception ee){System.out.println(ee);}	
			
			

	}
	void pesquisar() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/rentacar","root","");
			Statement stmt=con.createStatement();
		switch(op.getSelectedItem().toString()) {
		case "Matricula":
			if(tipo==true) {
				String sql="Select * from veiculos where Remove='0' and Matricula LIKE '" + sb.getText() + "%'";
				ResultSet rs=stmt.executeQuery(sql);
				Tabela.setModel(DbUtils.resultSetToTableModel(rs));
				con.close();
			}
			else {
				String sql="Select * from alugados where Remove='0' and Matricula LIKE '" + sb.getText() + "%'";
				ResultSet rs=stmt.executeQuery(sql);
				Tabela.setModel(DbUtils.resultSetToTableModel(rs));
				con.close();
			}
			
			break;
		case "Marca":
			if(tipo==true) {
				String sql="Select * from veiculos where Remove='0' and Marca LIKE '" + sb.getText() + "%'";
				ResultSet rs=stmt.executeQuery(sql);
				Tabela.setModel(DbUtils.resultSetToTableModel(rs));
				con.close();
			}
			else {
				String sql="Select * from alugados where Remove='0' and Marca LIKE '" + sb.getText() + "%'";
				ResultSet rs=stmt.executeQuery(sql);
				Tabela.setModel(DbUtils.resultSetToTableModel(rs));
				con.close();
			}
			break;
        case "Modelo":
        	if(tipo==true) {
				String sql="Select * from veiculos where Remove='0' and Modelo LIKE '" + sb.getText() + "%'";
				ResultSet rs=stmt.executeQuery(sql);
				Tabela.setModel(DbUtils.resultSetToTableModel(rs));
				con.close();
			}
			else {
				String sql="Select * from alugados where Remove='0' and Modelo LIKE '" + sb.getText() + "%'";
				ResultSet rs=stmt.executeQuery(sql);
				Tabela.setModel(DbUtils.resultSetToTableModel(rs));
				con.close();
			}
			break;
		case "Classe":
			if(tipo==true) {
				String sql="Select * from veiculos where Remove='0' and Classe LIKE '" + sb.getText() + "%'";
				ResultSet rs=stmt.executeQuery(sql);
				Tabela.setModel(DbUtils.resultSetToTableModel(rs));
				con.close();
			}
			else {
				String sql="Select * from alugados where Remove='0' and Classe LIKE '" + sb.getText() + "%'";
				ResultSet rs=stmt.executeQuery(sql);
				Tabela.setModel(DbUtils.resultSetToTableModel(rs));
				con.close();
			}
			break;
		case "Tp_Combustivel":
			if(tipo==true) {
				String sql="Select * from veiculos where Remove='0' and Tp_Combustivel LIKE '" + sb.getText() + "%'";
				ResultSet rs=stmt.executeQuery(sql);
				Tabela.setModel(DbUtils.resultSetToTableModel(rs));
				con.close();
			}
			else {
				String sql="Select * from alugados where Remove='0' and Tp_Combustivel LIKE '" + sb.getText() + "%'";
				ResultSet rs=stmt.executeQuery(sql);
				Tabela.setModel(DbUtils.resultSetToTableModel(rs));
				con.close();
			}
			break;
		case"Nome":
			if(tipo==false) {
				String sql="Select * from alugados where Remove='0' and Nome_Cliente LIKE '" + sb.getText() + "%'";
				ResultSet rs=stmt.executeQuery(sql);
				Tabela.setModel(DbUtils.resultSetToTableModel(rs));
				con.close();
			}
			
		   break;
		case "CC":
			if(tipo==false) {
				String sql="Select * from alugados where Remove='0' and CC LIKE '" + sb.getText() + "%'";
				ResultSet rs=stmt.executeQuery(sql);
				Tabela.setModel(DbUtils.resultSetToTableModel(rs));
				con.close();
			}
			
			break;
		}
		}catch(Exception ee){System.out.println(ee);}	
	}
		
		public Main() throws ParseException {
		
			Main = new JPanel();
			Main.setBackground(Color.LIGHT_GRAY);
			Main.setBorder(new EmptyBorder(5, 5, 5, 5));
			setContentPane(Main);
			Main.setLayout(null);
		
	    MaskFormatter mask = new MaskFormatter("AA-AA-AA");
	    MaskFormatter mask1 = new MaskFormatter("##/####");
		MaskFormatter mask2 = new MaskFormatter("##/####");
		MaskFormatter mask3 = new MaskFormatter("##/####");
		 MaskFormatter mask4 = new MaskFormatter("AA-AA-AA");
		 MaskFormatter mask5 = new MaskFormatter("##/####");
		//MaskFormatter money = new MaskFormatter("###�");
		
		
		
		op.setVisible(false);
		op.setBounds(672, 160, 124, 22);
		Main.add(op);
		
		JLabel l2 = new JLabel("Pesquisar:");
		l2.setVisible(false);
		l2.setBounds(506, 130, 87, 27);
		Main.add(l2);
		
		JLabel l1 = new JLabel("Pesquisar por:");
		l1.setVisible(false);
		l1.setBounds(672, 130, 87, 27);
		Main.add(l1);
		
		sb = new JTextField();
		sb.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				
				pesquisar();
			}
		});
		sb.setVisible(false);
		sb.setBounds(506, 160, 156, 20);
		sb.setColumns(10);
		Main.add(sb);

		
		
		
		panel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panel.setBackground(new Color(30, 144, 255));
		panel.setBounds(0, 0, 1100, 120);
		Main.add(panel);
		panel.setLayout(null);
		
		JLabel Logo = new JLabel();
		Logo.setBounds(30, 10, 150, 100);
		Logo.setIcon(logo);
		panel.add(Logo);
		
		JLabel Alugados = new JLabel("Alugados");
		Alugados.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		Alugados.setForeground(Color.BLACK);
		
		Alugados.setHorizontalAlignment(SwingConstants.CENTER);
		Alugados.setFont(new Font("Eras Bold ITC", Font.BOLD, 30));
		Alugados.setBounds(289, 10, 230, 100);
		panel.add(Alugados);
	
		JLabel Veiculos = new JLabel("Veiculos");
		Veiculos.setForeground(Color.BLACK);
		Veiculos.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		Veiculos.setHorizontalAlignment(SwingConstants.CENTER);
		Veiculos.setFont(new Font("Eras Bold ITC", Font.BOLD, 30));
		Veiculos.setBounds(670, 10, 230, 100);
		panel.add(Veiculos);
		
		JLabel Data = new JLabel("data");
		Data.setForeground(Color.BLACK);
		Data.setFont(new Font("Eras Bold ITC", Font.PLAIN, 14));
		Data.setBounds(999, 10, 111, 20);
		panel.add(Data);
		
		
		JLabel Hora = new JLabel("hora");
		Hora.setForeground(Color.BLACK);
		Hora.setFont(new Font("Eras Bold ITC", Font.PLAIN, 14));
		Hora.setBounds(1035, 25, 111, 20);
		panel.add(Hora);
				
					adcV.setVisible(false);
					adcV.setBackground(Color.WHITE);
					adcV.setBounds(165, 120, 929, 560);
					adcV.setLayout(null);
					adcV.setVisible(false);
					this.getContentPane().add(adcV);
					

		
		textmatricula = new JFormattedTextField();
		textmatricula.setText("");
		textmatricula.setFont(new Font("Dialog", Font.PLAIN, 23));
		textmatricula.setBounds(194, 98, 116, 30);
		mask.install(textmatricula);
		adcV.add(textmatricula);
		textmatricula.setColumns(10);
		
				
				JLabel Matricula_1 = new JLabel("Matricula:");
				Matricula_1.setFont(new Font("Dialog", Font.PLAIN, 25));
				Matricula_1.setBounds(74, 97, 116, 30);
				adcV.add(Matricula_1);
				
				JLabel lblVeiculo = new JLabel("Veiculo");
				lblVeiculo.setHorizontalAlignment(SwingConstants.CENTER);
				lblVeiculo.setFont(new Font("Dialog", Font.BOLD, 30));
				lblVeiculo.setBounds(348, 11, 135, 27);
				adcV.add(lblVeiculo);
				
				JPanel panel_1 = new JPanel();
				panel_1.setBackground(Color.BLACK);
				panel_1.setBounds(345, 45, 145, 2);
				adcV.add(panel_1);
				
				JPanel panel_1_1 = new JPanel();
				panel_1_1.setBackground(Color.BLACK);
				panel_1_1.setBounds(330, 50, 175, 2);
				adcV.add(panel_1_1);
				
				JLabel Marca_1 = new JLabel("Marca:");
				Marca_1.setFont(new Font("Dialog", Font.PLAIN, 25));
				Marca_1.setBounds(74, 139, 86, 30);
				adcV.add(Marca_1);
				
				JComboBox textmarca = new JComboBox();
				textmarca.setBorder(new CompoundBorder());
				textmarca.setEditable(true);
				textmarca.setModel(new DefaultComboBoxModel(new String[] {"Abarth", "Alfa Romeo", "Alpina", "Aston Martin", "Audi", "BMW", "Barkas", "Bentley", "Borgward", "Brilliance", "Buick", "Cadillac", "Caterham", "Chevrolet", "Chrysler", "Citroen", "Corvette", "Cupra", "DS Automobiles", "Dacia", "Daewoo", "Daihatsu", "Dodge", "Ferrari", "Fiat", "Ford", "Honda", "Hyundai", "Infiniti", "Isuzu", "Iveco", "Jaguar", "Jeep", "Kia", "Lada", "Lamborghini", "Lancia", "Land Rover", "Lexus", "Lotus", "MAN", "MG Rover", "MINI", "Maserati", "Maybach", "Mazda", "Mercedes-Benz", "Mitsubishi", "Nissan", "Opel", "Peugeot", "Piaggio (Vespa)", "Pontiac", "Porsche", "Proton", "Renault", "Rolls Royce", "Rover", "Saab", "Seat", "Skoda", "Smart", "Ssangyong", "StreetScooter", "Subaru", "Suzuki", "Tata", "Tesla", "Toyota", "Trabant", "Triumph", "Volkswagen", "Volvo", "Wartburg", "Westfield", "Zastava"}));
				textmarca.setBounds(160, 139, 150, 32);
				adcV.add(textmarca);
				
				JLabel modelo = new JLabel("Modelo:");
				modelo.setFont(new Font("Dialog", Font.PLAIN, 25));
				modelo.setBounds(74, 180, 98, 30);
				adcV.add(modelo);
				
				textmodelo = new JTextField();
				textmodelo.setBounds(170, 182, 150, 29);
				adcV.add(textmodelo);
				textmodelo.setColumns(10);
				
				JLabel Ano_1 = new JLabel("Ano:");
				Ano_1.setFont(new Font("Dialog", Font.PLAIN, 25));
				Ano_1.setBounds(74, 222, 62, 30);
				adcV.add(Ano_1);
				
				adcV.add(textmatricula);
				textmatricula.setColumns(10);
				
				JFormattedTextField textano = new JFormattedTextField();
				textano.setText("");
				textano.setFont(new Font("Dialog", Font.PLAIN, 23));
				textano.setColumns(10);
				textano.setBounds(133, 222, 116, 30);
				mask5.install(textano);
				adcV.add(textano);
				
				
				JLabel cor = new JLabel("Cor:");
				cor.setFont(new Font("Dialog", Font.PLAIN, 25));
				cor.setBounds(74, 263, 62, 30);
				adcV.add(cor);
				
				JComboBox textcor = new JComboBox();
				textcor.setEditable(true);
				textcor.setModel(new DefaultComboBoxModel(new String[] {"Amarelo", "Azul", "Castanho", "Cinza", "Cinzento", "Creme", "Laranja", "Preto", "Rosa", "Roxo", "Verde", "Vermelho"}));
				textcor.setBounds(133, 263, 135, 32);
				adcV.add(textcor);
				
				JLabel classe = new JLabel("Classe:");
				classe.setFont(new Font("Dialog", Font.PLAIN, 25));
				classe.setBounds(74, 304, 86, 30);
				adcV.add(classe);
				
				JComboBox textclasse = new JComboBox();
				textclasse.setEditable(true);
				textclasse.setModel(new DefaultComboBoxModel(new String[] {"Carrinha", "Cup\u00EA", "Desportivos", "Econ\u00F3micos", "Jipes", "Mini", "Suv"}));
				textclasse.setBounds(160, 306, 108, 30);
				adcV.add(textclasse);
				
				JLabel lblProximaInspeo = new JLabel("Proxima Inspe\u00E7\u00E3o:");
				lblProximaInspeo.setFont(new Font("Dialog", Font.PLAIN, 25));
				lblProximaInspeo.setBounds(531, 99, 208, 30);
				adcV.add(lblProximaInspeo);
				
				JLabel lblSeguro = new JLabel("Seguro:");
				lblSeguro.setFont(new Font("Dialog", Font.PLAIN, 25));
				lblSeguro.setBounds(531, 140, 88, 30);
				adcV.add(lblSeguro);
				
				JLabel lblNPortas = new JLabel("N\u00BA Portas:");
				lblNPortas.setFont(new Font("Dialog", Font.PLAIN, 25));
				lblNPortas.setBounds(531, 182, 116, 30);
				adcV.add(lblNPortas);
				
				JLabel lblNLugares = new JLabel("N\u00BA Lugares:");
				lblNLugares.setFont(new Font("Dialog", Font.PLAIN, 25));
				lblNLugares.setBounds(531, 222, 135, 30);
				adcV.add(lblNLugares);
				
				JComboBox textportas = new JComboBox();
				textportas.setEditable(true);
				textportas.setModel(new DefaultComboBoxModel(new String[] {"3", "4", "5"}));
				textportas.setBounds(657, 182, 82, 31);
				adcV.add(textportas);
				
				JComboBox textlugares = new JComboBox();
				textlugares.setEditable(true);
				textlugares.setModel(new DefaultComboBoxModel(new String[] {"2", "3", "4", "5", "7", "9", "11"}));
				textlugares.setBounds(667, 222, 82, 31);
				adcV.add(textlugares);
				
				JLabel searchlogo = new JLabel("");
				searchlogo.setVisible(false);
				searchlogo.setBounds(706, 32, 24, 20);
				searchlogo.setIcon(search);
				adcV.add(searchlogo);
				
				JFormattedTextField textinspe�ao = new JFormattedTextField();
				textinspe�ao.setText("");
				textinspe�ao.setFont(new Font("Dialog", Font.PLAIN, 23));
				textinspe�ao.setColumns(10);
				textinspe�ao.setBounds(749, 99, 116, 30);
				mask3.install(textinspe�ao);
				adcV.add(textinspe�ao);
				
				JFormattedTextField textseguro = new JFormattedTextField();
				textseguro.setText("");
				textseguro.setFont(new Font("Dialog", Font.PLAIN, 23));
				textseguro.setColumns(10);
				textseguro.setBounds(623, 140, 116, 30);
				mask2.install(textseguro);
				adcV.add(textseguro);
				
				JLabel lblTpcombustivel = new JLabel("Tp.Combustivel:");
				lblTpcombustivel.setFont(new Font("Dialog", Font.PLAIN, 25));
				lblTpcombustivel.setBounds(531, 263, 186, 30);
				adcV.add(lblTpcombustivel);
				
				JComboBox textcomb = new JComboBox();
				textcomb.setModel(new DefaultComboBoxModel(new String[] {"Diesel", "Gasolina", "GPL", "Eletrico"}));
				textcomb.setEditable(true);
				textcomb.setBounds(714, 263, 82, 31);
				adcV.add(textcomb);
				
				JButton btnConcluir = new JButton("Concluir");
				btnConcluir.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						String Matricula=textmatricula.getText();
						String Marca=textmarca.getSelectedItem().toString();
						String Modelo=textmodelo.getText();
						String Classe=textclasse.getSelectedItem().toString();
						String Ano=textano.getText();
						String Seguro=textseguro.getText();
						String Inspe��o=textinspe�ao.getText();
						String Tp_Combustivel=textcomb.getSelectedItem().toString();
						String Cor=textcor.getSelectedItem().toString();
						String N�Portas=textportas.getSelectedItem().toString();
						String N�Lugares=textlugares.getSelectedItem().toString();
					    int Activo=1;
						
						System.out.println("a inserir.... na bd");
						String sql="";
						if (edit==false) {
							 sql="Insert into veiculos (Matricula, Marca, Modelo,Classe, Ano,Seguro, Inspe��o, Tp_Combustivel, Cor,NPortas, NLugares, Activo) Values ('"+Matricula+"', '"+Marca+"', '"+Modelo+"','"+Classe+"', '"+Ano+"', '"+Seguro+"','"+Inspe��o+"', '"+Tp_Combustivel+"', '"+Cor+"','"+N�Portas+"', '"+N�Lugares+"', '"+Activo+"')";
							
						}
						else {
							 sql="Update veiculos set Matricula = '"+ Matricula +"',Marca='"+Marca+"',Modelo='"+Modelo+"',Classe='"+Classe+"',Ano='"+Ano+"',Seguro='"+Seguro+"',Inspe��o='"+Inspe��o+"',Tp_Combustivel='"+Tp_Combustivel+"',Cor='"+Cor+"',N�Portas='"+N�Portas+"',N�Lugares='"+N�Lugares+"' where Matricula = '"+ auxmatricula +"'";
						}

						 try{
								Class.forName("com.mysql.jdbc.Driver");
								con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rentacar","root","");
								Statement stmt=con.createStatement();
								int ok=stmt.executeUpdate(sql);
								con.close();
								if(ok>0){
									System.out.println("Utilizador inserido/editado na bd");	
									
								}
								} catch(Exception er) {
								System.out.println(er);
							}
						
						
					}
				});
				btnConcluir.setBounds(780, 510, 90, 30);
				adcV.add(btnConcluir);
				adcA.setVisible(false);
				adcA.setBackground(Color.WHITE);
				adcA.setBounds(165, 120, 929, 560);
				adcA.setLayout(null);
				this.getContentPane().add(adcA);
				
				JLabel lblNome = new JLabel("Nome:");
				lblNome.setFont(new Font("Dialog", Font.PLAIN, 25));
				lblNome.setBounds(76, 113, 116, 30);
				adcA.add(lblNome);
				
				JLabel lblCc = new JLabel("CC:");
				lblCc.setFont(new Font("Dialog", Font.PLAIN, 25));
				lblCc.setBounds(76, 182, 52, 30);
				adcA.add(lblCc);
				
				JLabel lblMatricula = new JLabel("Matricula:");
				lblMatricula.setFont(new Font("Dialog", Font.PLAIN, 25));
				lblMatricula.setBounds(76, 251, 116, 30);
				adcA.add(lblMatricula);
				
				textField_2 = new JTextField();
				textField_2.setBounds(156, 113, 260, 31);
				adcA.add(textField_2);
				textField_2.setColumns(10);
				
				textField_3 = new JTextField();
				textField_3.setColumns(10);
				textField_3.setBounds(123, 182, 260, 31);
				adcA.add(textField_3);
				
				JFormattedTextField formattedTextField = new JFormattedTextField();
				formattedTextField.setFont(new Font("Dialog", Font.PLAIN, 23));
				formattedTextField.setColumns(10);
				formattedTextField.setBounds(193, 251, 116, 30);
				mask4.install(formattedTextField);
				adcA.add(formattedTextField);
				
				JLabel lblSinal = new JLabel("Sinal:");
				lblSinal.setFont(new Font("Dialog", Font.PLAIN, 25));
				lblSinal.setBounds(548, 324, 72, 30);
				adcA.add(lblSinal);
				
				JLabel lblPercentagemDepsito = new JLabel("Combustivel:");
				lblPercentagemDepsito.setFont(new Font("Dialog", Font.PLAIN, 25));
				lblPercentagemDepsito.setBounds(537, 182, 161, 30);
				adcA.add(lblPercentagemDepsito);
				
				JLabel lblProteoContraTodos = new JLabel("Seguro contra tudo:");
				lblProteoContraTodos.setFont(new Font("Dialog", Font.PLAIN, 25));
				lblProteoContraTodos.setBounds(537, 113, 233, 30);
				adcA.add(lblProteoContraTodos);
				
				JCheckBox checkBox = new JCheckBox("");
				checkBox.setBounds(763, 120, 21, 23);
				adcA.add(checkBox);
				adcA.setVisible(false);
				adcA.setBackground(Color.WHITE);
				adcA.setBounds(165, 120, 929, 560);
				adcA.setLayout(null);
				adcA.setVisible(false);
				this.getContentPane().add(adcA);
				
				
				
				JSpinner spinner = new JSpinner();
				spinner.setModel(new SpinnerNumberModel(0, -1, 1, 1));
				spinner.setBounds(805, 185, 16, 27);
				adcA.add(spinner);
				
				JProgressBar pb = new JProgressBar();
				pb.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						pb.setValue(pb.getMousePosition().x);;
					}
				});
				pb.setBounds(700, 185, 100, 27);
				pb.setStringPainted(true);
				int value2 = (Integer) spinner.getValue();
				pb.setValue(value2);
				adcA.add(pb);
				
				JTextField sinal = new JTextField();
				sinal.setText("");
				sinal.setFont(new Font("Dialog", Font.PLAIN, 23));
				sinal.setColumns(4);
				sinal.setBounds(617, 251, 60, 30);
				adcA.add(sinal);
				
				JLabel lblSinal_1 = new JLabel("\u20AC");
				lblSinal_1.setFont(new Font("Dialog", Font.PLAIN, 25));
				lblSinal_1.setBounds(678, 251, 30, 30);
				adcA.add(lblSinal_1);
				
				JLabel lblAlugados = new JLabel("Alugados");
				lblAlugados.setHorizontalAlignment(SwingConstants.CENTER);
				lblAlugados.setFont(new Font("Dialog", Font.BOLD, 30));
				lblAlugados.setBounds(350, 5, 135, 40);
				adcA.add(lblAlugados);
				
				JPanel panel_1_2 = new JPanel();
				panel_1_2.setBackground(Color.BLACK);
				panel_1_2.setBounds(347, 45, 145, 2);
				adcA.add(panel_1_2);
				
				JPanel panel_1_1_1 = new JPanel();
				panel_1_1_1.setBackground(Color.BLACK);
				panel_1_1_1.setBounds(332, 50, 175, 2);
				adcA.add(panel_1_1_1);
				
				JButton concluir2 = new JButton("Concluir");
				concluir2.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
					   
						String Matricula=formattedTextField.getText();
						auxmatricula=Matricula;
						loadaux();
						String Marca=marcasql;
						String Modelo=modelosql;
						String Nome=textField_2.getText();
						String CC=textField_3.getText();
						String Data=new SimpleDateFormat("dd/MM/yyyy HH:mm").format(new Date(System.currentTimeMillis()));
						SimpleDateFormat df = new SimpleDateFormat("dd MMM yyyy HH:mm:ss");
						String DataF = df.format(picker.getDate()) + " GMT";
						
						//String DataF=picker.getDate().toString();
						int Gasolina=pb.getValue();
						int Prote��o=0;
						if (checkBox.isSelected()==true) {
							 Prote��o=1;
						}
						int Sinal=Integer.parseInt(sinal.getText());
						int Pre�o=Integer.parseInt(pre�o.getText());
						
						
						System.out.println("a inserir.... na bd");

						String sql="Insert into alugados (Matricula, Marca, Modelo,Nome_Cliente, CC,Data_Inicial,Data_Final, Gasolina, Prote��o_Total, Sinal,Pre�o) Values ('"+Matricula+"', '"+Marca+"', '"+Modelo+"','"+Nome+"', '"+CC+"', '"+Data+"', '"+DataF+"','"+Gasolina+"', '"+Prote��o+"', '"+Sinal+"','"+Pre�o+"')";
						
						 try{
								Class.forName("com.mysql.jdbc.Driver");
								con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rentacar","root","");
								Statement stmt=con.createStatement();
								int ok=stmt.executeUpdate(sql);
								con.close();
								if(ok>0){
									System.out.println("Utilizador inserido na bd");	
									
								}
								} catch(Exception er) {
								System.out.println(er);
							}
					}
				});
				concluir2.setBounds(780, 480, 90, 30);
				adcA.add(concluir2);
				
				JLabel lblPreo = new JLabel("Pre\u00E7o:");
				lblPreo.setFont(new Font("Dialog", Font.PLAIN, 25));
				lblPreo.setBounds(537, 251, 83, 30);
				adcA.add(lblPreo);
				
				pre�o = new JTextField();
				pre�o.setText("");
				pre�o.setFont(new Font("Dialog", Font.PLAIN, 23));
				pre�o.setColumns(4);
				pre�o.setBounds(617, 325, 60, 30);
				adcA.add(pre�o);
				
				JLabel lblSinal_1_1 = new JLabel("\u20AC");
				lblSinal_1_1.setFont(new Font("Dialog", Font.PLAIN, 25));
				lblSinal_1_1.setBounds(679, 324, 30, 30);
				adcA.add(lblSinal_1_1);
				
				JLabel lblDataFinal = new JLabel("Data Final:");
				lblDataFinal.setFont(new Font("Dialog", Font.PLAIN, 25));
				lblDataFinal.setBounds(76, 325, 122, 30);
				adcA.add(lblDataFinal);
				
				
				tab.setBounds(175, 193, 867, 487);
				tab.setVisible(false);
				Main.add(tab);
				
				
				
				Tabela=new JTable();
				
				tab.setViewportView(Tabela);
				
				JPanel panel2 = new JPanel();
				panel2.setBackground(new Color(30, 144, 255));
				panel2.setVisible(false);
				panel2.setBorder(new MatteBorder(0, 1, 1, 1, (Color) new Color(0, 0, 0)));
				panel2.setBounds(0, 80, 165, 600);
				Main.add(panel2);
				panel2.setLayout(null);
				
				JLabel Consultar = new JLabel("Consultar");
				Consultar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
				Consultar.setBorder(new MatteBorder(0, 8, 0, 0, (Color) Color.BLACK));
				Consultar.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseEntered(MouseEvent e) {
						Consultar.setBorder(new MatteBorder(0, 8, 0, 0, (Color) new Color(204, 0,51 )));
					}
					@Override
					public void mouseExited(MouseEvent e) {
						Consultar.setBorder(new MatteBorder(0, 8, 0, 0, (Color) new Color(0, 0, 0)));
					}
					@Override
					public void mouseClicked(MouseEvent arg0) {
						
							adcV.setVisible(false);
							adcA.setVisible(false);
							l1.setVisible(true);
							l2.setVisible(true);
							sb.setVisible(true);
							op.setVisible(true);
							tab.setVisible(true);
							if(tipo==false) {
								loada();
							}
							else {
								loadv();

							}
						
						
						
					}
				});
				
				Consultar.setBackground(Color.WHITE);
				Consultar.setForeground(Color.BLACK);
				Consultar.setHorizontalAlignment(SwingConstants.CENTER);
				Consultar.setFont(new Font("Eras Demi ITC", Font.PLAIN, 27));
				Consultar.setBounds(6, 80, 155, 59);
				panel2.add(Consultar);
				
				JLabel Adicionar = new JLabel("Adicionar");
				Adicionar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
				Adicionar.setBorder(new MatteBorder(0, 8, 0, 0, (Color) new Color(0, 0, 0)));
				Adicionar.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseEntered(MouseEvent e) {
						Adicionar.setBorder(new MatteBorder(0, 8, 0, 0, (Color) new Color(204, 0,51 )));
					}
					@Override
					public void mouseExited(MouseEvent e) {
						Adicionar.setBorder(new MatteBorder(0, 8, 0, 0, (Color) new Color(0, 0, 0)));
					}
					@Override
					public void mouseClicked(MouseEvent e) {
						l1.setVisible(false);
						l2.setVisible(false);
						sb.setVisible(false);
						op.setVisible(false);
						tab.setVisible(false);
						switch (btns) {
						case 1: adcV.setVisible(true);
						break;
						case 2: adcA.setVisible(true);
						break;
						}

					}
				});
				Adicionar.setHorizontalAlignment(SwingConstants.CENTER);
				Adicionar.setForeground(Color.BLACK);
				Adicionar.setFont(new Font("Eras Demi ITC", Font.PLAIN, 27));
				Adicionar.setBackground(Color.WHITE);
				Adicionar.setBounds(6, 180, 155, 59);
				panel2.add(Adicionar);
				
				JLabel Remover = new JLabel("Remover");
				Remover.setVisible(false);
				Remover.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
				Remover.setBorder(new MatteBorder(0, 8, 0, 0, (Color) new Color(0, 0, 0)));
				Remover.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseEntered(MouseEvent e) {
						Remover.setBorder(new MatteBorder(0, 8, 0, 0, (Color) new Color(204, 0,51 )));
						
					}
					@Override
					public void mouseExited(MouseEvent e) {
						Remover.setBorder(new MatteBorder(0, 8, 0, 0, (Color) new Color(0, 0, 0)));
					}
					@Override
					public void mouseClicked(MouseEvent e) {
						
						if(tipo==false)	{
							String sql="Update alugados set Remove = '1' where Id = '"+ auxmatricula+"'";
							 try{
									Class.forName("com.mysql.jdbc.Driver");
									con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rentacar","root","");
									Statement stmt=con.createStatement();
									int ok=stmt.executeUpdate(sql);
									con.close();
									if(ok>0){
										System.out.println("alugado removido na bd");	
										
									}
									} catch(Exception er) {
									System.out.println(er);
								}
							loada();
						}
						else {
							String sql="Update veiculos set Remove = '1' where Matricula = '"+ auxmatricula+"'";
							 try{
									Class.forName("com.mysql.jdbc.Driver");
									con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rentacar","root","");
									Statement stmt=con.createStatement();
									int ok=stmt.executeUpdate(sql);
									con.close();
									if(ok>0){
										System.out.println("veiculo removido na bd");	
										
									}
									} catch(Exception er) {
									System.out.println(er);
								}
								loadv();	
						}
						
						
					}
				});
				Remover.setHorizontalAlignment(SwingConstants.CENTER);
				Remover.setForeground(Color.BLACK);
				Remover.setFont(new Font("Eras Demi ITC", Font.PLAIN, 27));
				Remover.setBackground(Color.WHITE);
				Remover.setBounds(6, 280, 155, 59);
				panel2.add(Remover);
				
				JLabel Editar = new JLabel("Editar");
				Editar.setVisible(false);
				Editar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
				Editar.setBorder(new MatteBorder(0, 8, 0, 0, (Color) new Color(0, 0, 0)));
				Editar.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseEntered(MouseEvent e) {
						Editar.setBorder(new MatteBorder(0, 8, 0, 0, (Color) new Color(204, 0, 51)));
					}
					@Override
					public void mouseExited(MouseEvent e) {
						Editar.setBorder(new MatteBorder(0, 8, 0, 0, (Color) new Color(0, 0, 0)));
					}
					@Override
					public void mouseClicked(MouseEvent e) {
						adcV.setVisible(true);
						tab.setVisible(false);
						edit=true;
						textmatricula.setText(Tabela.getModel().getValueAt(row, 0).toString());
					    textmarca.setSelectedItem(Tabela.getModel().getValueAt(row, 1).toString());
					    textmodelo.setText(Tabela.getModel().getValueAt(row, 2).toString());
					    textclasse.setSelectedItem(Tabela.getModel().getValueAt(row, 3).toString());
					    textano.setText(Tabela.getModel().getValueAt(row, 4).toString());
					    textseguro.setText(Tabela.getModel().getValueAt(row, 5).toString());
					    textinspe�ao.setText(Tabela.getModel().getValueAt(row, 6).toString());
					    textcomb.setSelectedItem(Tabela.getModel().getValueAt(row, 7).toString());
					    textcor.setSelectedItem(Tabela.getModel().getValueAt(row, 8).toString());
					    textportas.setSelectedItem(Tabela.getModel().getValueAt(row, 9).toString());
					    textlugares.setSelectedItem(Tabela.getModel().getValueAt(row, 10).toString());
					}
				});
				Editar.setHorizontalAlignment(SwingConstants.CENTER);
				Editar.setForeground(Color.BLACK);
				Editar.setFont(new Font("Eras Demi ITC", Font.PLAIN, 27));
				
						Editar.setBackground(Color.WHITE);
						Editar.setBounds(6, 380, 155, 59);
						panel2.add(Editar);
		
		
		spinner.addChangeListener(new ChangeListener() {
		public void stateChanged(ChangeEvent e) {
			if((Integer) spinner.getValue()==1) {
				value = pb.getValue();
				value=value+5;
				pb.setValue(value);
				spinner.setValue(0);
			}
			else if((Integer) spinner.getValue()==-1) {
				value = pb.getValue();
				value=value-5;
				pb.setValue(value);
				spinner.setValue(0);
			}
		}
		});
		
	
		
		
		Veiculos.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				l1.setVisible(false);
				l2.setVisible(false);
				sb.setVisible(false);
				op.setVisible(false);
				panel2.setVisible(true);
				Veiculos.setForeground(new Color(204,0,51));
				Alugados.setForeground(new Color(0,0,0));
				Remover.setText("Remover");
				tab.setVisible(false);
				adcA.setVisible(false);
				tipo=true;
				btns = 1;
				op.setModel(new DefaultComboBoxModel(new String[] {"Matricula", "Marca", "Modelo", "Classe", "Tp_Combustivel"}));
			}
		});
		
		Alugados.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				l1.setVisible(false);
				l2.setVisible(false);
				sb.setVisible(false);
				op.setVisible(false);
				panel2.setVisible(true);
				Alugados.setForeground(new Color(204,0,51));
				Veiculos.setForeground(new Color(0,0,0));
				Remover.setText("Finalizar");
				tab.setVisible(false);
				adcV.setVisible(false);
				tipo=false;
				btns = 2;
				op.setModel(new DefaultComboBoxModel(new String[] {"Matricula", "Marca", "Modelo", "Classe", "Tp_Combustivel","Nome","CC"}));
			}
		});
		Tabela.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Remover.setVisible(true);
				
				row = Tabela.rowAtPoint( e.getPoint() );
	            auxmatricula=Tabela.getModel().getValueAt(row, 0).toString();
	            if(tipo==true) {
	            	Editar.setVisible(true);
	            }

			}
		});
		Timer timer=new Timer();
		TimerTask task =new TimerTask() {

			@Override
			public void run() {
				
				Data.setText(new SimpleDateFormat("dd/MM/yyyy").format(new Date(System.currentTimeMillis())));
				Hora.setText(new SimpleDateFormat("HH:mm").format(new Date(System.currentTimeMillis())));
			}
			
		};
		

		timer.scheduleAtFixedRate(task, 0, 80);
	}
		private Color rgb(int i, int j, int k) {
			// TODO Auto-generated method stub
			return null;
		}
}
